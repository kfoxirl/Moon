﻿$keep = 50
$files = Get-ChildItem "D:\syngo.plaza\Temp\HierarchyConflictImages\" -Recurse | Where-Object { $_.LastWriteTime -lt ([DateTime]::Now.AddMinutes(-1))} | Sort Name -Descending
$freespace = Get-WmiObject -Class Win32_logicalDisk | ? {$_.DriveType -eq '3' -and $_.DeviceId -eq 'D:'}
$drive = ($FreeSpace.DeviceID).Split("=")
$percent = "{0:P2}" -f ($freespace.FreeSpace / $freespace.Size)

if ($percent -lt '70%')
{
	if ($keep -lt $files.Count)
	{
	  
	  $files[$keep..($files.Count-1)] | Remove-Item	
	}
	#output statistics
	Write-Host "Files deleted $($files.Count)" -ForegroundColor green
	Write-Host "Drive Space Used is  $($percent)" -ForegroundColor green
}

else
{
	Write-Host "Drive Space Used is only  $($percent)" -ForegroundColor green
}

