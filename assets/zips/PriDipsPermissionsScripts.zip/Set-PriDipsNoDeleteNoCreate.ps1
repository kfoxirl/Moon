Param(
	[Parameter(Mandatory=$True,ValueFromPipeline=$False,Position=0,HelpMessage="User Profile")]
		[string]$TargetUserProfile
 )

$UserProfileDirectory = "D:\syngo.plaza\Config\User";
$TargetDirectory = $UserProfileDirectory + "\" + $TargetUserProfile + "\PriDips";

Write-Host "User Profile: $TargetUserProfile"; 

if (Test-Path -Path $TargetDirectory) {

	Write-Host "$TargetDirectory exists. Updating permissions for target directory.";

	# Set the properties for the new NoDelete/NoCreate FileSystemAccessRule that we will add to the target's ACL
	$objUser = New-Object System.Security.Principal.NTAccount([string]("Everyone")); 
	$colRights = [System.Security.AccessControl.FileSystemRights]"CreateFiles,Delete,DeleteSubdirectoriesAndFiles"; 
	$InheritanceFlag = [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
	$PropagationFlag = [System.Security.AccessControl.PropagationFlags]::None
	$objType =[System.Security.AccessControl.AccessControlType]::Deny; 

	# Create the new FileSystemAccessRule
	$ReadOnlyAccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($objUser,$colRights,$InheritanceFlag,$PropagationFlag,$objType);
	
	Write-Host "Creating ReadOnly FileSystemAccessRule for $TargetDirectory";

	# Get the target directory's ACL
	$objACL = Get-Acl -Path $TargetDirectory;

	# Maintain the inheritance, then add the new FileSystemAccessRule to the ACL
	$isProtected = $false
	$preserveInheritance = $true 
	$objACL.SetAccessRuleProtection($isProtected,$preserveInheritance);
	$objACL.SetAccessRule($ReadOnlyAccessRule);

	# Set the ACL to the target directory
	Set-ACL -Path $TargetDirectory -AclObject $objACL;
	
	Write-Host "Added ReadOnly FileSystemAccessRule to ACL for $TargetDirectory";
}
else {
	Write-Error "$TargetDirectory does not exist.";
}