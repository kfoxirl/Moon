Param(
	[Parameter(Mandatory=$True,ValueFromPipeline=$False,Position=0,HelpMessage="User Profile")]
		[string]$TargetUserProfile
 )

$UserProfileDirectory = "D:\syngo.plaza\Config\User";
$TargetDirectory = $UserProfileDirectory + "\" + $TargetUserProfile + "\PriDips";

Write-Host "User Profile: $TargetUserProfile"; 

if (Test-Path -Path $TargetDirectory) {
	
	Write-Host "Removing ReadOnly FileSystemAccessRule for $TargetDirectory";

	# Get the target directory's ACL
	$objACL = Get-Acl -Path $TargetDirectory;

	# Remove the FileSystemAccessRule from te ACL
	$AccessRule = ((Get-Acl -Path $TargetDirectory).Access | Where-Object { $_.AccessControlType -eq 'Deny' })
	$objACL.RemoveAccessRule($AccessRule);

	# Set the ACL to the target directory
	Set-ACL -Path $TargetDirectory -AclObject $objACL;
	
	Write-Host "ReadOnly FileSystemAccessRule removed from ACL for $TargetDirectory";
}
else {
	Write-Error "$TargetDirectory does not exist.";
}