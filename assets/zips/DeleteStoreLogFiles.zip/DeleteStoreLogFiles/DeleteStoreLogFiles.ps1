Stop-Service syngo.common.lcmservice

$limit = (Get-Date).AddDays(-7)
$path = "C:\Store\log"

# Delete files older than the $limit.
Get-ChildItem -Path $path -Recurse -Force | Where-Object { !$_.PSIsContainer -and $_.LastAccessTime -lt $limit } | Remove-Item -Force

start-service syngo.common.lcmservice