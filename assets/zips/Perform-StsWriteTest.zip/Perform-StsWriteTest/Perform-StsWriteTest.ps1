$ScriptDirectory = Split-Path $MyInvocation.MyCommand.Path;

Function Write-Log() {
    Param ([string]$type,
            [string]$line,
            [string]$ScriptLogfile)
  
    switch($type) { 
		'D'	{ $msgType =     " DEBUG "; }
		'W' 	{ $msgType = " WARNING "; }
		'E' 	{ $msgType = " ERROR "; }
		default { $msgType = " INFO "; } 
	}

    $ProcessId = " " + $pid;    
	
    Add-Content $ScriptLogfile $($(Get-Date).ToString("yyyy/MM/dd HH:mm:ss") + $ProcessId + $msgType + $line)
}

# Set the default message severity
$Severity = "I";

# Set our script logfile name 
$ScriptLogfile = (Join-Path $ScriptDirectory ("RSC-PerformStsWriteTest_" + $env:computername + "_" + (Get-Date).ToString("yyyyMMdd") + ".log"));

# Set the STS path based on which ever server the script's running on 
$StsPath = "\\mcsradfs1.mcstore.local\plazafsctl\Rsc-StsWriteTest";

# Set the source & destination path to the test image
$TestImageSrc = (Join-Path $ScriptDirectory "SMPTEPattern_512x512.DCM"); 
$TestImageDst = (Join-Path $StsPath "SMPTEPattern_512x512.DCM");

try {
    # Copy the test image to the temp location and record the total number of milliseconds
    $TotalTime = (Measure-Command { Copy-Item $TestImageSrc -Destination $TestImageDst}).TotalMilliseconds; 
}
catch [Exception] {
    Write-Log "E" "Exception encountered copying the test file: $_" $ScriptLogfile;
}

# Set the message severity based on the write test completion time
if ($TotalTime -gt 1000) {
    $Severity = "W";
    if ($TotalTime -gt 5000) {
        $Severity = "E";
    }
}

# Write the logfile message
Write-Log $Severity ("Test image written to $StsPath in $TotalTime ms.") $ScriptLogfile; 

# Remove the file
If (Test-Path -Path $TestImageDst) {
    try {
        Remove-Item -Path $TestImageDst -Force
    }
    catch [Exception] {
        Write-Log "E" "Exception encountered removing test file: $_" $ScriptLogfile;
    }
}




