
$ScriptDirectory = Split-Path $MyInvocation.MyCommand.Path;

# Test if the PowerShell profile exists. If not, create it
if (!(Test-Path $profile)) {
  New-Item -path $profile -Type file �Force
}

# Set the default location where the Powershell module will reside
$RscToolsDir = "D:\Support\RSC\PowerShell"

# Test if the target directory for the PowerShell module exists. If not, create it. 
if (!(Test-Path $RscToolsDir)) {
    New-Item -Path $RscToolsDir -Type directory �Force
}

# Move the PS Module into the RscTools directory
Move-Item -Path (Join-Path $ScriptDirectory RscPSModules_VB20A.psm1) -Destination $RscToolsDir -Force

# Add line to the PowerShell profile to set the default starting location if it's not already set
if (!(Select-String -Pattern 'Set-Location' -Path $profile)) {
    Add-Content $profile "Set-Location D:\syngo.plaza\log";
}

# Add line to the PowerShell profile to load the module on startup if it hasn't already been set
if (!(Select-String -Pattern 'RscPSModules_VB20A.psm1' -Path $profile)) {
    Add-Content $profile "Import-Module -DisableNameChecking $RscToolsDir\RscPSModules_VB20A.psm1"
}