# Set DB connection parameters
$RegPath = "HKLM:\SOFTWARE\Wow6432Node\Siemens\PC-Viewer\Install_Tool";
if (Test-Path -Path $RegPath) {
    $aSqlServer = $(Get-ItemProperty -Path $RegPath).DBINSTANCE;
    $aPort = $(Get-ItemProperty -Path $RegPath).DBPORT;
}
else {
    Write-Error "Could not get DB server and/or port from registry.";
    Exit;
}

$aDbInstance = "tcp:$aSqlServer,$aPort";
$aDbName = "pcv_dicom_db";

# Prepare for the Sql Server connection
$aConnOptions = ("Server = $aDbInstance; Database = $aDbName; Integrated Security = True");

# Set path to the Syngo Plaza logfiles
$PlazaLogDirectory = $(Get-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Siemens\PC-Viewer\PATH").LOG;

# Set path to the Syngo Plaza system Config directory 
$PlazaCfgDirectory = "D:\syngo.plaza\Config\System\Central";

# Set the Archive Config and NAS MP if applicable
$ArchiveConfig = [xml](get-content -path (Join-Path $PlazaCfgDirectory syngo.Plaza.Services.DataManagement.ArchiveConfig.xml));
$ArchiveType = $ArchiveConfig.syngoPlaza.ArchiveConfig.ArchiveType;
$ArchiveTarget = if ($ArchiveType -eq "NAS") { $ArchiveConfig.syngoPlaza.ArchiveConfig.NasSettingsElement.MountPointsElement.MountPointList.MountPoint.Path } else { $ArchiveConfig.syngoPlaza.ArchiveConfig.DICOMLTA.SCPSettings.AET }

# Set default day range for queries 
[int]$QueryDayRange = -7;

# Date Formats used
$DateFormats = [string[]]("yyyy.MM.dd HH:mm:ss","yyyyMMddHHmmss", "yyyyMMdd HHmmss","d/M/yyyy HH:mm:ss:fff", "yyyy-MMM-dd-ddd HH:mm:ss", "MM/dd/yyyy HH:mm:ss","MMM dd yyyy  h:mmtt","dd.MM.yyyy/HH:mm:ss","yyyy.MM.dd");

function Format-FileSize() {
    Param ([long]$size)
    If     ($size -gt 1TB) {[string]::Format("{0:0.00} TB", $size / 1TB)}
    ElseIf ($size -gt 1GB) {[string]::Format("{0:0.00} GB", $size / 1GB)}
    ElseIf ($size -gt 1MB) {[string]::Format("{0:0.00} MB", $size / 1MB)}
    ElseIf ($size -gt 1KB) {[string]::Format("{0:0.00} kB", $size / 1KB)}
    ElseIf ($size -gt 0)   {[string]::Format("{0:0.00} B", $size)}
    Else                   {""}
}

# Function to insure uniform display of DateTime values
function Format-DateTime() {
	Param ([DateTime]$InputDateTime)
	
	Get-Date -Date $InputDateTime -Format "MM/dd/yyyy HH:mm:ss";
}

# Function to insure uniform display of Date values
function Format-Date() {
	Param ([DateTime]$InputDateTime)
	
	Get-Date -Date $InputDateTime -Format "MM/dd/yyyy";
}

# Function to  display the hour time range between two DateTime values 
function Format-TimeRange() {
	Param ([DateTime]$InputDateTime1, [DateTime]$InputDateTime2)
	
	$Hour1 = Get-Date -Date $InputDateTime1 -Format "HH:mm:ss";
    $Hour2 = Get-Date -Date $InputDateTime2 -Format "HH:mm:ss";
    
    return ($Hour1 + "-" + $Hour2);
}

# Function to parse various DateTime formats
function Parse-DateTime() {
	Param ([string]$InputDateTime)
	
    try {
	    [DateTime]::ParseExact($InputDateTime, $DateFormats, $null, [System.Globalization.DateTimeStyles]::None);
    }
    catch {
        return $InputDateTime;
    } 
}

<#
    .SYNOPSIS
        This Cmdlet lists Procedure level information based on the Patient ID passed. 

    .DESCRIPTION
        This Cmdlet lists Procedure level information based on the Patient ID passed. 

    .EXAMPLE
        Get-PatientInfo -PatientID <patient_id>

    .NOTES
        Lists information related to the Patient ID passed
#>

function global:Get-PatientInfo {

    [CmdletBinding(
        DefaultParameterSetName="PatientId",
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]

    Param(
	    [Parameter(Mandatory=$True,ValueFromPipeline=$True,Position=0,HelpMessage="Patient ID")]
		[string]$PatientId
    )

    Begin {
		try {
			$aConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
		}
		catch {
    		Write-Error "Could not create connection to the DB server";
    		Exit;
		}
    }

    Process {
    
        try 
        {
	        $aConnection.Open();	
	        Write-Verbose $("Connection to DB instance $aSqlServer established.");

            if ($aConnection.State -eq "Closed") {
                Write-Error $("Connection to DB instance $aSqlServer is not open.");
  	        }
            
            $PatientQuery = "SELECT pat1.[Patient ID], pat1.[Patient Name], stu1.[RIS Case ID], stu1.[Study Description], stu1.[Study Date], stu1.[Study Time], stu1.[Write Date Time],
                             CASE (convert(nvarchar(1),stu1.[InSTS]) + convert(nvarchar(1),stu1.[InLts]))
							    WHEN '00' THEN 'Nearline/Unarchived'
								WHEN '01' THEN 'Nearline/Archived'
								WHEN '10' THEN 'Online/Unarchived'
								WHEN '11' THEN 'Online/Archived'
								ELSE 'Unknown Status'
						     END
                             FROM [pcv_dicom_db].[dbo].[Study] stu1
                             INNER JOIN [pcv_dicom_db].[dbo].[Patient] pat1 
                                ON pat1.[Patient UID]=stu1.[Patient UID]
                             WHERE pat1.[Patient ID]=@PatientId";
			
            # Look up the pertinant procedure info based on the input parameter passed.
	        $sqlCmd = New-Object System.Data.SqlClient.SqlCommand($PatientQuery, $aConnection);	
	        $sqlCmd.Parameters.AddWithValue("@PatientId", $PatientId) >> $null;
  	        $aReader = $sqlCmd.ExecuteReader();
						
			# Define fields and objects to hold values retrieved fron the DB
            $ProcInfoArray = @();
            
            while($aReader.Read()) {

                # retrieve the DB fields
                $PatientId = $aReader.GetValue(0);
                $PatientName = $aReader.GetValue(1);
                $AccessionNumber = $aReader.GetValue(2);
		        $StudyDescription = $aReader.GetValue(3);
			    $StudyCreationDate = $aReader.GetValue(4);
			    $StudyCreationTime = $aReader.GetValue(5);
				$StudyWriteDateTime = $aReader.GetValue(6);
                $StudyOnlineStatus = $aReader.GetValue(7);
				
                # Format the Date/Time fields						
				$StudyCreationDateTime = Parse-DateTime ($StudyCreationDate + " " + $StudyCreationTime);
				$StudyWriteDateTime = Parse-DateTime $StudyWriteDateTime;  

				# Add the fields to each StudyInfoObject			
                $ProcInfoOutputObj = New-Object PSObject;	
                $ProcInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Patient Name" -Value $PatientName;
                $ProcInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Patient ID" -Value $PatientId;
                $ProcInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Accession Number" -Value $AccessionNumber;  
                $ProcInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Study Description" -Value $StudyDescription;
                $ProcInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Study Creation DateTime" -Value (Format-DateTime $StudyCreationDateTime);  
                $ProcInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Study Write DateTime" -Value (Format-DateTime $StudyWriteDateTime); 	
                $ProcInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Online Status" -Value $StudyOnlineStatus;

                # Add each ProcInfoObject to the Array
                $ProcInfoArray += $ProcInfoOutputObj;
				Write-Debug "`$RowCount $RowCount";
	        }

	        $aReader.Close();
						
			if ($ProcInfoArray.Length -lt 1) {
				Write-Host "`n`t*** No data found for Patient ID $PatientId ***`n" -ForegroundColor Yellow;
			}
            else {
                $ProcInfoArray | Format-Table -AutoSize
            }
       }
        catch [Exception] {
            Write-Error "An exception occurred: $_";
            Write-Debug $StackTrace
        }
        Finally {
  	        if ($aConnection.State -ne "Closed") {
                $aConnection.Close()  
                Write-Verbose $("Connection to DB instance $aSqlServer closed."); 
            }
        }  
    }

    End{}
}

<#
    .SYNOPSIS
        This Cmdlet lists Study and Series level information based on the Accession Number passed. 

    .DESCRIPTION
        This Cmdlet lists Study and Series level information based on the Accession Number passed. 

    .EXAMPLE
        Get-ProcedureInfo -AccNum <accession_number>

    .NOTES
        Lists information related to the Accession Number passed
#>

function global:Get-ProcedureInfo {

    [CmdletBinding(
        DefaultParameterSetName="AccNum",
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]

    Param(
	    [Parameter(Mandatory=$True,ValueFromPipeline=$True,Position=0,HelpMessage="Accession Number")]
		[string]$AccNum
    )

    Begin {
		try {
			$aConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
		}
		catch {
    		Write-Error "Could not create connection to the DB server";
    		Exit;
		}
    }

    Process {
    
        try 
        {
	        $aConnection.Open();	
	        Write-Verbose $("Connection to DB instance $aSqlServer established.");

            if ($aConnection.State -eq "Closed") {
                Write-Error $("Connection to DB instance $aSqlServer is not open.");
  	        }
        						
	        $ProcedureQuery = "SELECT pat1.[Patient ID], pat1.[Patient Name], 
                                      stu1.[Study Instance UID], stu1.[Study Description], stu1.[Study Date], stu1.[Study Time], stu1.[Write Date Time],
                                      CASE (convert(nvarchar(1),stu1.[InSTS]) + convert(nvarchar(1),stu1.[InLts]))
										WHEN '00' THEN 'Nearline/Unarchived'
										WHEN '01' THEN 'Nearline/Archived'
										WHEN '10' THEN 'Online/Unarchived'
										WHEN '11' THEN 'Online/Archived'
										ELSE 'Unknown Status'
									  END
                               FROM [pcv_dicom_db].[dbo].[Study] stu1
                               INNER JOIN [pcv_dicom_db].[dbo].[Patient] pat1 
                                ON pat1.[Patient UID]=stu1.[Patient UID]
                               WHERE stu1.[RIS Case ID]=@AccNum
                               ORDER BY stu1.[Write Date Time] asc";
			
            # Look up the pertinant procedure info based on the input parameter passed.
	        $sqlCmd = New-Object System.Data.SqlClient.SqlCommand($ProcedureQuery, $aConnection);	
	        $sqlCmd.Parameters.AddWithValue("@AccNum", $AccNum) >> $null;
  	        $aReader = $sqlCmd.ExecuteReader();
						
			# Define fields and objects to hold values retrieved fron the DB
            $StudyInfoArray = @();
						
	        while($aReader.Read()) {

                # retrieve the DB fields
                $PatientId = $aReader.GetValue(0);
                $PatientName = $aReader.GetValue(1);
                $StudyInstanceUID = $aReader.GetValue(2);
		        $StudyDescription = $aReader.GetValue(3);
			    $StudyCreationDate = $aReader.GetValue(4);
			    $StudyCreationTime = $aReader.GetValue(5);
				$StudyWriteDateTime = $aReader.GetValue(6);
                $StudyOnlineStatus = $aReader.GetValue(7);
				
                # Format the Date/Time fields						
				$StudyCreationDateTime = Parse-DateTime ($StudyCreationDate + " " + $StudyCreationTime);
				$StudyWriteDateTime = Parse-DateTime $StudyWriteDateTime;  

				# Add the fields to each StudyInfoObject			
                $StudyInfoOutputObj = New-Object PSObject;	
                $StudyInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Patient Name" -Value $PatientName;
                $StudyInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Patient ID" -Value $PatientId; 
                $StudyInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Study Instance UID" -Value $StudyInstanceUID; 
                $StudyInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Study Description" -Value $StudyDescription;
                $StudyInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Study Creation DateTime" -Value (Format-DateTime $StudyCreationDateTime);  
                $StudyInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Study Write DateTime" -Value (Format-DateTime $StudyWriteDateTime); 	
                $StudyInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Online Status" -Value $StudyOnlineStatus;

                # Add each StudyInfoObject to the Array
                $StudyInfoArray += $StudyInfoOutputObj;
				Write-Debug "`$RowCount $RowCount";
	        }

	        $aReader.Close();
						
			if ($StudyInfoArray.Length -lt 1) {
				Write-Host "`n`t*** No data found for Accession Number $AccNum ***`n" -ForegroundColor Yellow;
			}
			else {
					# Write out the Patient/Study Information
                    $TableFormat = @{Expression={$_.'Patient Name'};Label="Patient Name";width=30},
                                   @{Expression={$_.'Patient ID'};Label="Patient ID";width=15},
                                   @{Expression={$_.'Study Instance UID'};Label="Study Instance UID";width=50},
                                   @{Expression={$_.'Study Description'};Label="Study Description";width=25},
                                   @{Expression={$_.'Study Creation DateTime'};Label="Study Creation DateTime";width=25},
                                   @{Expression={$_.'Study Write DateTime'};Label="Study Write DateTime";width=25},
                                   @{Expression={$_.'Online Status'};Label="Online Status"};
                    
                    $StudyInfoArray | Format-Table $TableFormat;
			}
        }
        catch [Exception] {
            Write-Error "An exception occurred: $_";
            Write-Debug $StackTrace
        }
        Finally {
  	        if ($aConnection.State -ne "Closed") {
                $aConnection.Close()  
                Write-Verbose $("Connection to DB instance $aSqlServer closed."); 
            }
        }  
    }

    End{}
}

<#
    .SYNOPSIS
        This Cmdlet lists Study and Series level information based on the Study Instance UID passed. 

    .DESCRIPTION
        This Cmdlet lists Study and Series level information based on the Study Instance UID passed. 

    .EXAMPLE
        Get-StudyInfo -StudyUid <study_instance_uid>

    .NOTES
        Lists information related to the Study UID passed
#>

function global:Get-StudyInfo {

    [CmdletBinding(
        DefaultParameterSetName="StudyUid",
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]

    Param(
	    [Parameter(Mandatory=$True,ValueFromPipeline=$True,Position=0,HelpMessage="Study Instance UID")]
		[string]$StudyUid
    )

    Begin {
		try {
			$aConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
		}
		catch {
    		Write-Error "Could not create connection to the DB server";
    		Exit;
		}
    }

    Process {
    
        try 
        {
	        $aConnection.Open();	
	        Write-Verbose $("Connection to DB instance $aSqlServer established.");

            if ($aConnection.State -eq "Closed") {
                Write-Error $("Connection to DB instance $aSqlServer is not open.");
  	        }
        						
            $StudyQuery = "SELECT pat1.[Patient ID], pat1.[Patient Name], stu1.[RIS Case ID], stu1.[Study Description], stu1.[Study Date], stu1.[Study Time], stu1.[Write Date Time], 
                           ser1.[Series Instance UID], ser1.[Series Description], ser1.[Series Number], ser1.[Modality], aet.ReceiveAET, ser1.[Image Count],
                           CASE (convert(nvarchar(1),ser1.[InSTS]) + convert(nvarchar(1),ser1.[InLts]))
										WHEN '00' THEN 'Nearline/Unarchived'
										WHEN '01' THEN 'Nearline/Archived'
										WHEN '10' THEN 'Online/Unarchived'
										WHEN '11' THEN 'Online/Archived'
										ELSE 'Unknown Status'
					       END
                           FROM [pcv_dicom_db].[dbo].[Study] stu1
                           INNER JOIN [pcv_dicom_db].[dbo].[Patient] pat1 
                            ON pat1.[Patient UID]=stu1.[Patient UID]
                           INNER JOIN [pcv_dicom_db].[dbo].[Series] ser1 
                            ON stu1.[Study Instance UID]=ser1.[Study Instance UID]
                           INNER JOIN [pcv_dicom_db].[dbo].[StudyComponent] sc 
                            ON sc.PPSID=ser1.PPSID 
                            AND sc.[Study Instance UID]=ser1.[Study Instance UID]
                           INNER JOIN [pcv_dicom_db].[dbo].[NetworkAET] aet 
                            ON sc.ReceiveAETID=aet.ReceiveAETID
                           WHERE stu1.[Study Instance UID]=@StudyUid";
                           

	        $sqlCmd = New-Object System.Data.SqlClient.SqlCommand($StudyQuery, $aConnection);	
	        $sqlCmd.Parameters.AddWithValue("@StudyUid", $StudyUid) >> $null;
  	        $aReader = $sqlCmd.ExecuteReader();
			
			# Keep a count of the number of lines returned. 
			[int]$RowCount = 0; 
			
			# Define fields and objects to hold values retrieved fron the DB
			[collections.SortedList]$SeriesInfo = @{};
            $StudyInfoOutputObj = New-Object PSObject;
            $SeriesInfoArray = @();
						
	        while($aReader.Read()) {
				if ($RowCount -eq 0) {
                    $PatientId = $aReader.GetValue(0);
                    $PatientName = $aReader.GetValue(1);
                    $AccessionNumber = $aReader.GetValue(2);
					$StudyDescription = $aReader.GetValue(3);
					$StudyCreationDate = $aReader.GetValue(4);
					$StudyCreationTime = $aReader.GetValue(5);
					$StudyWriteDateTime = $aReader.GetValue(6);
                    
										
					$StudyCreationDateTime = Parse-DateTime ($StudyCreationDate + " " + $StudyCreationTime);
					$StudyWriteDateTime = Parse-DateTime $StudyWriteDateTime;

                    $StudyInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Patient Name/ID" -Value ($PatientName + "/" + $PatientId);
                    $StudyInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Accession Number" -Value $AccessionNumber;
                    $StudyInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Study Instance UID" -Value $StudyUid;  
                    $StudyInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Study Creation DateTime" -Value (Format-DateTime $StudyCreationDateTime);  
                    $StudyInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Study Write DateTime" -Value (Format-DateTime $StudyWriteDateTime);                       
				}	
							
                $SeriesInfoOutputObj = New-Object PSObject;		
                $SeriesInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Series Instance UID" -Value $aReader.GetValue(7);
                $SeriesInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Description" -Value $aReader.GetValue(8);
                $SeriesInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Number" -Value $aReader.GetValue(9);
                $SeriesInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Modality" -Value $aReader.GetValue(10);
                $SeriesInfoOutputObj | Add-Member -MemberType NoteProperty -Name "AET" -Value $aReader.GetValue(11);
                $SeriesInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Image Count" -Value $aReader.GetValue(12);
                $SeriesInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Online Status" -Value $aReader.GetValue(13);
               
                $SeriesInfoArray += $SeriesInfoOutputObj;
				Write-Debug "`$RowCount $RowCount";
				$RowCount++;
	        }

	        $aReader.Close();
						
			if ($SeriesInfoArray.Length -lt 1) {
				Write-Host "`n`t*** No data found for Study UID $StudyUid ***`n" -ForegroundColor Yellow;
			}
			else {
					# Write out the Patient/Study/Series Information
                    $StudyInfoOutputObj | Format-List;
                    $SeriesInfoArray | Format-Table -AutoSize;
			}
        }
        catch [Exception] {
            Write-Error "An exception occurred: $_";
            Write-Debug $StackTrace
        }
        Finally {
  	        if ($aConnection.State -ne "Closed") {
                $aConnection.Close()  
                Write-Verbose $("Connection to DB instance $aSqlServer closed."); 
            }
        }  
    }

    End{}
}

<#
    .SYNOPSIS
        This Cmdlet lists Series, and Image level information based on the Series Instance UID passed. 

    .DESCRIPTION
        This Cmdlet lists Series, and Image level information based on the Series Instance UID passed. 

    .EXAMPLE
        Get-SeriesInfo -SeriesUid <series_instance_uid>

    .NOTES
        Lists information related to the Series UID passed
#>

function global:Get-SeriesInfo {

    [CmdletBinding(
        DefaultParameterSetName="SeriesUid",
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]

    Param(
	    [Parameter(Mandatory=$True,ValueFromPipeline=$True,Position=0,HelpMessage="Series Instance UID")]
			[string]$SeriesUid, 
			[switch]$Detail
    )

    Begin {
		try {
			$aConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
            $bConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
		}
		catch {
    		Write-Error "Could not create connections to the DB server";
    		Exit;
		}
    }
	
    Process {
    
        try 
        {
	        $aConnection.Open();
            $bConnection.Open();	
	        Write-Verbose ("Connections to DB instance $aSqlServer established.");

            if ($aConnection.State -eq "Closed") {
                Write-Error ("Connection to DB instance $aSqlServer is not open.");
  	        }
        
	        $StationDetailsQuery = "SELECT [HashKey], [HostName] FROM [pcv_dicom_db].[dbo].[StationDetails]"; 
	        $StationStorePathQuery = "SELECT [HashKey], [LongLocalPath] 
                                      FROM [pcv_dicom_db].[dbo].[StationStorePath]
                                      WHERE [HostName]=@HostName";
				
	        # Initialize the hash table that holds the StationDetails
	        [hashtable]$StationDetails = @{};
	        $aCmd = $aConnection.CreateCommand();
  	        $aCmd.CommandText = $StationDetailsQuery;
  	        $aReader = $aCmd.ExecuteReader();
	
	        while ($aReader.Read()) {
	        
	          $StationDetailsHash = $aReader.GetValue(0);
              $HostName = $aReader.GetValue(1);

              # Initialize the hash table that holds the StationStorePath
	          [hashtable]$StationStorePath = @{};
	           $sqlCmd = New-Object System.Data.SqlClient.SqlCommand($StationStorePathQuery, $bConnection);	
	           $sqlCmd.Parameters.AddWithValue("@HostName", $HostName) >> $null;
  	           $bReader = $sqlCmd.ExecuteReader();
	
	          while ($bReader.Read()){
    	         $StationStorePath.Add($bReader.GetValue(0),@($HostName, $bReader.GetValue(1)));
	          }
	          $bReader.Close();
              Write-Verbose ("StationStorePath table populated. " + ($StationStorePath.Count) + " row(s) added.");	            
	          
              #Finally, add the StationStorePath table to the StationDetails table with the StationDetailsHash as the ke  
    	      $StationDetails.Add($StationDetailsHash,$StationStorePath);  
	        }	
	        $aReader.Close();
            Write-Verbose ("StationDetails table populated. " + ($StationDetails.Count) + " row(s) added.");
			
	        # Now that we've initialized the hashtables, look up the image locators based on the input parameter passed.
	        $ImageQuery = "SELECT pat.[Patient ID], pat.[Patient Name], stu.[Study Instance UID], stu.[RIS Case ID], ser.[Modality], ser.[Series Date], ser.[Series Time], ser.[Series Description], 
                            CASE ser.[Status]
                                WHEN '0' THEN 'In Progress'
                                WHEN '1' THEN 'Complete'
                                WHEN '2' THEN 'Imported'
                                WHEN '3' THEN 'Errored'
                                WHEN '4' THEN 'Renamed'
                                WHEN '5' THEN 'Status Conflict'
                                ELSE 'Unknown Status'    
                            END,
                            img.[Image Filename],img.[SOP Instance UID],img.[Image Number], img.[Image Date],img.[Image Time]
                            FROM [pcv_dicom_db]..[Image] img
                            INNER JOIN [pcv_dicom_db]..[Series] ser 
                                ON ser.UniqueSeriesID = img.UniqueSeriesID
                            INNER JOIN [pcv_dicom_db]..[Study] stu 
                                ON stu.[Study Instance UID]=ser.[Study Instance UID]
                            INNER JOIN [pcv_dicom_db]..[Patient] pat 
                                ON pat.[Patient UID]=stu.[Patient UID]
                            WHERE ser.[Series Instance UID]=@SeriesUid
                            ORDER BY img.[Image Number] asc";
			
	        $sqlCmd = New-Object System.Data.SqlClient.SqlCommand($ImageQuery, $aConnection);	
	        $sqlCmd.Parameters.AddWithValue("@SeriesUid", $SeriesUid) >> $null;
  	        $aReader = $sqlCmd.ExecuteReader();
			
			# Keep a count of the number of lines returned. 
			[int]$ImgCount = 0; 
			
			# Define fields and objects to hold values retrieved fron the DB
			[string]$SeriesDescription = "";
			[string]$SeriesModality = "";
			[string]$SeriesCreationDate = "";
			[string]$SeriesWriteDateTime = "";
			[hashtable]$ImageInfo = @{};			
			[long]$TotalBytes = 0; 
						
	        while($aReader.Read()) {
				if ($ImgCount -eq 0) {
                    $PatientId = $aReader.GetValue(0);
                    $PatientName = $aReader.GetValue(1);
                    $StudyUid = $aReader.GetValue(2);
                    $AccNum = $aReader.GetValue(3);
					$SeriesModality = $aReader.GetValue(4);
					$SeriesCreationDate = $aReader.GetValue(5);

                    Write-Debug "`$SeriesCreationDate: $SeriesCreationDate";
					if (([DBNull]::Value).Equals($SeriesCreationDate)) { $SeriesCreationDate = "19700101"; }
					
                    Write-Debug "`$SeriesCreationDateTime: $SeriesCreationDateTime";
					$SeriesCreationTime = $aReader.GetValue(6);
					if (([DBNull]::Value).Equals($SeriesCreationTime)) { $SeriesCreationTime = "000001"; }
					else { $SeriesCreationTime = $SeriesCreationTime.Substring(0,6); }
					             	
					if ($SeriesCreationDate.Length -lt 8) { $SeriesCreationDate = "19700101"; }
					if ($SeriesCreationTime.Length -lt 6) { $SeriesCreationTime = "000001"; }
					$SeriesCreationDateTime = Parse-DateTime ($SeriesCreationDate + " " + $SeriesCreationTime);
					
                    $SeriesDescription = $aReader.GetValue(7);
					$SeriesStatus = $aReader.GetValue(8);
				}	
			
		        $File = $aReader.GetValue(9);
		        $SopUid = $aReader.GetValue(10);
				$ImageNumber = $aReader.GetValue(11);   
		
		        # Look up the Hostname and StsPath from the hashtable
                $HostName = $StationDetails.Get_Item($File.Substring(0,1)).Get_Item($File.Substring(1,1))[0];
		        $StsPath = $StationDetails.Get_Item($File.Substring(0,1)).Get_Item($File.Substring(1,1))[1];
		
		        # Build the file path
		        $FilePath = $StsPath + $File.Substring(2,3) + "\" + $File.Substring(5,1) + "\" + $File.Substring(6,2) + "\" + $File.Substring(8);
				
				# Add the image data to the ImageInfo hashtable with the SopUid as the key
				$PathInfo = @($ImageNumber, $HostName, $FilePath);
				$ImageInfo.Add($SopUid,$PathInfo);
				
				$ImgCount++;
	        }

	        $aReader.Close();
						
			if ($ImgCount -lt 1) {
				Write-Host "`n`t*** No Images Found for Series UID $SeriesUid ***`n" -ForegroundColor Yellow;
			}
			else {
                    # Add Patient/Study/Series Information to output opbject
                    $StuSerOutputObj = New-Object PSObject;
                    $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "Patient Name/ID" -Value ($PatientName + "/" + $PatientId);
                    $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "Accession Number" -Value $AccNum;
                    $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "Study Instance UID" -Value $StudyUid;
                    $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "Series Instance UID" -Value $SeriesUid;
                    $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "Series Description " -Value $SeriesDescription;
                    $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "Series Modality" -Value $SeriesModality;
                    $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "Series Creation DateTime" -Value (Format-DateTime $SeriesCreationDateTime);
                    $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "Series Status" -Value $SeriesStatus;
                    
                    				
					$ImgCount = 0; 
                    $SopInfoArray = @();					
										
					foreach ($Sop in $ImageInfo.Keys) {
						$OutArray = $ImageInfo.Get_Item($Sop);

                        Write-Debug "`$OutArray: $OutArray";

                        $SopInfoOutputObj = New-Object PSObject; 
						
                        # If the file path exists, print out the Sop UID along with the file write date/time and size
                        if (Test-Path -Path $OutArray[2]) { 
						    $ImageWriteDateTime = (Get-ChildItem $OutArray[2]).CreationTime;
						    $FileSize = (Get-ChildItem $OutArray[2]).Length;

                            $TotalBytes += $FileSize;
 						
						    if ($ImgCount -eq 0) {
							    $FirstImageWritten = $ImageWriteDateTime;
							    $LastImageWritten = $ImageWriteDateTime;
						    }
											
						    if ($ImageWriteDateTime -gt $LastImageWritten) { $LastImageWritten = $ImageWriteDateTime; }
						    if ($ImageWriteDateTime -lt $FirstImageWritten) { $FirstImageWritten = $ImageWriteDateTime; } 
						
						    if ($Detail -eq $true) {
                                $SopInfoOutputObj | Add-Member -MemberType NoteProperty -Name "SOP Instance Uid" -Value $Sop;
                                $SopInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Host Name" -Value $OutArray[1];
                                $SopInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Image Path" -Value $OutArray[2];
                                $SopInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Image Creation DateTime" -Value (Format-DateTime $ImageWriteDateTime);
                                $SopInfoOutputObj | Add-Member -MemberType NoteProperty -Name "File Size" -Value (Format-FileSize $FileSize -as [int]); 
						    }
						
						    $ImgCount++;
                        }
                        # If the file does not exist, print out SOP UID and path, but indicate that the file info is not available
                        else {
                            $SopInfoOutputObj | Add-Member -MemberType NoteProperty -Name "SOP Instance Uid" -Value $Sop;
                            $SopInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Host Name" -Value $OutArray[1];
                            $SopInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Image Path" -Value $OutArray[2];
                            $SopInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Image Creation DateTime" -Value "--/--/---- --:--:-- --";
                            $SopInfoOutputObj | Add-Member -MemberType NoteProperty -Name "File Size" -Value "-----"; 
                        }

                        $SopInfoArray += $SopInfoOutputObj;
					}

                    # Print out summary stats for the series
                    if ($ImgCount -gt 0) {
                        $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "First Image Write Date/Time" -Value (Format-DateTime $FirstImageWritten);
                        $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "Last Image Write Date/Time" -Value (Format-DateTime $LastImageWritten);
				
					    # Calculate the total storage time based on the firtst and last image written
					    [int]$StorageTime = (New-TimeSpan -Start $FirstImageWritten -End $LastImageWritten).TotalSeconds;
					    [int]$TotalMBytes = ($TotalBytes / 1Mb);
				
					    $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "Total Images Written" -Value $ImgCount;
                        $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "Total Bytes Written" -Value (Format-FileSize $TotalBytes -as [int]);
                        $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "Total Storage Time" -Value ([string]::Format("{0:0.00} sec", $StorageTime));

                        if ($StorageTime -gt 0) {
                            $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "Images/Sec" -Value ([string]::Format("{0:0.00}", $ImgCount/$StorageTime));
                            $StuSerOutputObj | Add-Member -MemberType NoteProperty -Name "MBytes/Sec" -Value ([string]::Format("{0:0.00}", $TotalMBytes/$StorageTime));
                        }
                    }

                    # Print out the the Patient/Study/Series information and file details if requested
                    $StuSerOutputObj | Format-List;
					if($Detail -eq $true) {
						Write-Host "";
                        $SopInfoArray | Format-Table -Autosize;
                    }
			}
        }
        catch [Exception] {
            Write-Error "An exception occurred: $_";
            Write-Debug $StackTrace
        }
        Finally {
  	        if ($aConnection.State -ne "Closed") { $aConnection.Close(); }
            if ($bConnection.State -ne "Closed") { $bConnection.Close(); }

            Write-Verbose $("Connections to DB instance $aSqlServer closed."); 
        }  
    }

    End{}
}

<#
    .SYNOPSIS
        This Cmdlet lists Image level information based on the SOP Instance UID passed. 

    .DESCRIPTION
        This Cmdlet lists Image level information based on the SOP Instance UID passed. 

    .EXAMPLE
        Get-ObjectInfo -SopInstanceUid <sop_instance_uid>

    .NOTES
        Lists information related to the SOP Instance UID passed
#>

function global:Get-ObjectInfo {

    [CmdletBinding(
        DefaultParameterSetName="SopUid",
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]

    Param(
	    [Parameter(Mandatory=$True,ValueFromPipeline=$True,Position=0,HelpMessage="SOP Instance UID")]
		[string]$SopUid
    )

    Begin {
		try {
			$aConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
            $bConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
		}
		catch {
    		Write-Error "Could not create connections to the DB server";
    		Exit;
		}
	}	

    Process {
    
        try 
        {
	        $aConnection.Open();
            $bConnection.Open();	
	        Write-Verbose ("Connections to DB instance $aSqlServer established.");

            if ($aConnection.State -eq "Closed") {
                Write-Error ("Connection to DB instance $aSqlServer is not open.");
  	        }
        
	        $StationDetailsQuery = "SELECT [HashKey], [HostName] FROM [pcv_dicom_db].[dbo].[StationDetails]"; 
	        $StationStorePathQuery = "SELECT [HashKey], [LongLocalPath] 
                                      FROM [pcv_dicom_db].[dbo].[StationStorePath]
                                      WHERE [HostName]=@HostName";
				
	        # Initialize the hash table that holds the StationDetails
	        [hashtable]$StationDetails = @{};
	        $aCmd = $aConnection.CreateCommand();
  	        $aCmd.CommandText = $StationDetailsQuery;
  	        $aReader = $aCmd.ExecuteReader();
	
	        while ($aReader.Read()) {
	        
	          $StationDetailsHash = $aReader.GetValue(0);
              $HostName = $aReader.GetValue(1);

              # Initialize the hash table that holds the StationStorePath
	          [hashtable]$StationStorePath = @{};
	           $sqlCmd = New-Object System.Data.SqlClient.SqlCommand($StationStorePathQuery, $bConnection);	
	           $sqlCmd.Parameters.AddWithValue("@HostName", $HostName) >> $null;
  	           $bReader = $sqlCmd.ExecuteReader();
	
	          while ($bReader.Read()){
    	         $StationStorePath.Add($bReader.GetValue(0),@($HostName, $bReader.GetValue(1)));
	          }
	          $bReader.Close();
              Write-Verbose ("StationStorePath table populated. " + ($StationStorePath.Count) + " row(s) added.");	            
	          
              #Finally, add the StationStorePath table to the StationDetails table with the StationDetailsHash as the ke  
    	      $StationDetails.Add($StationDetailsHash,$StationStorePath);  
	        }	
	        $aReader.Close();
            Write-Verbose ("StationDetails table populated. " + ($StationDetails.Count) + " row(s) added.");
			
	        # Now that we've initialized the hashtables, look up the object info based on the input parameter passed.
	        $ImageQuery = "SELECT ser.[Series Instance UID],sop.[SOPClassUID],img.[Image Number],img.[Image Date],img.[Image Time],
       						img.[CreationTime],img.[Image Type],img.[Image Filename],img.[Space Used],
                            CASE img.[Archived]
                                WHEN '0' THEN 'Queued for Archiving'
                                WHEN '1' THEN 'In Progress'
                                WHEN '2' THEN 'Archived'
                                WHEN '3' THEN 'Errored'
                                ELSE 'Unknown Archive Status'
                            END
  							FROM [pcv_dicom_db]..[Image] img
                            INNER JOIN [pcv_dicom_db]..[UniqueSOPClassUID] sop 
                                ON img.[UniqueSOPClassUID]=sop.[UniqueSOPClassUID] 
						    INNER JOIN [pcv_dicom_db]..[Series] ser 
                                ON img.[UniqueSeriesID]=ser.[UniqueSeriesID]
  							WHERE img.[SOP Instance UID]=@SopUid";
			
            Write-Verbose ("Executing query against Image table for SOP UID " + $SopUid);
	        $sqlCmd = New-Object System.Data.SqlClient.SqlCommand($ImageQuery, $aConnection);	
	        $sqlCmd.Parameters.AddWithValue("@SopUid", $SopUid) >> $null;
  	        $aReader = $sqlCmd.ExecuteReader();
			
			# Keep a count of the number of lines returned. 
			[int]$ImgCount = 0; 
						
	        while($aReader.Read()) {

				$SeriesUID = $aReader.GetValue(0);
				$SopClassUID = $aReader.GetValue(1);
				$ImgNumber = $aReader.GetValue(2);
				
				$ImgCreationDate = $aReader.GetValue(3);
				$ImgCreationTime = $aReader.GetValue(4);	
                
				if ($ImgCreationDate.Length -lt 8) { $ImgCreationDate = "19700101"; }
                
				if ($ImgCreationTime.Length -lt 6) { 
                    $ImgCreationTime = "000001"; 
                }
                else {
                    $ImgCreationDateTime = $ImgCreationDateTime.Substring(0,6);
                }
                
				Write-Debug "`$ImgCreationDate $ImgCreationDate";
				Write-Debug "`$ImgCreationTime $ImgCreationTime";
				$ImgCreationDateTime = Parse-DateTime ($ImgCreationDate + " " + $ImgCreationTime);
			
				$ImgType = $aReader.GetValue(6);
		        $File = $aReader.GetValue(7);
		        
		        # Look up the Hostname and StsPath from the hashtables
                $HostName = $StationDetails.Get_Item($File.Substring(0,1)).Get_Item($File.Substring(1,1))[0];
		        $StsPath = $StationDetails.Get_Item($File.Substring(0,1)).Get_Item($File.Substring(1,1))[1];
		
		        # Build the file path
		        $FilePath = $StsPath + $File.Substring(2,3) + "\" + $File.Substring(5,1) + "\" + $File.Substring(6,2) + "\" + $File.Substring(8);
			
                if (Test-Path -Path $FilePath) {
                    $ImgWriteDateTime = (Get-ChildItem $FilePath).CreationTime; 
				    $ImgSizeC = $(Format-FileSize (Get-ChildItem $FilePath).Length -as [int]);
                }
                else {
                    $ImgWriteDateTime = "--/--/---- --:--:-- --";
                    $ImgSizeC = "------";
                }

				$ImgSizeU = $(Format-FileSize $aReader.GetValue(8) -as [int]);				
				$ArchStatus = $aReader.GetValue(9);
								
				$ImgCount++;
	        }

	        $aReader.Close();
						
			if ($ImgCount -lt 1) {
				Write-Host "`n`t*** No Objects Found for SOP Instance UID $SopUid ***`n" -ForegroundColor Yellow;
			}
			else {
                    # Write out the Series Information
                    $SopOutputObj = New-Object PSObject;
                    $SopOutputObj | Add-Member -MemberType NoteProperty -Name "Series Instance UID" -Value $SeriesUid;
                    $SopOutputObj | Add-Member -MemberType NoteProperty -Name "SOP Instance UID" -Value $SopUid;
                    $SopOutputObj | Add-Member -MemberType NoteProperty -Name "SOP Class UID" -Value $SopClassUid;
                    $SopOutputObj | Add-Member -MemberType NoteProperty -Name "Server::FilePath" -Value ($HostName + "::" + $FilePath);
                    $SopOutputObj | Add-Member -MemberType NoteProperty -Name "File Create DateTime" -Value (Format-DateTime $ImgCreationDateTime);
                    $SopOutputObj | Add-Member -MemberType NoteProperty -Name "File Write DateTime" -Value (Format-DateTime $ImgWriteDateTime);
                    $SopOutputObj | Add-Member -MemberType NoteProperty -Name "File Size (Uncompressed)" -Value $ImgSizeU;
                    $SopOutputObj | Add-Member -MemberType NoteProperty -Name "File Size (Compressed)" -Value $ImgSizeC;
                    $SopOutputObj | Add-Member -MemberType NoteProperty -Name "File Type" -Value $ImgType;
                    $SopOutputObj | Add-Member -MemberType NoteProperty -Name "Archive Status" -Value $ArchStatus;
                    $SopOutputObj | Format-List; 
			}
        }
        catch [Exception] {
            Write-Error "An exception occurred: $_";
            Write-Debug $StackTrace
        }
        Finally {
  	        if ($aConnection.State -ne "Closed") {
                $aConnection.Close();
                $bConnection.Close();   
                Write-Verbose $("Connections to DB instance $aSqlServer closed."); 
            }
        }  
    }

    End{}
}

<#
    .SYNOPSIS
        This Cmdlet lists DICOM association information related to the DICOM SCP Server. 

    .DESCRIPTION
        This Cmdlet lists DICOM association information related to the DICOM SCP Server. 

    .EXAMPLE
        Get-DcmReceieveInfo -AET <Application_Entity_Title> | 
							-Logfile <alternate_logfile_path> | 
							-MinAssocTime <associations_open_longer_than_n_seconds>
							-Open <True|False> 

    .NOTES
        This Cmdlet lists DICOM association information related to the DICOM SCP Server. 
#>

function global:Get-DcmAssociationInfo {

    [CmdletBinding(
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]

	Param(
		[Parameter(Mandatory=$False,ValueFromPipeline=$True,Position=0,HelpMessage="AET")]
			[string]$AET,
		[Parameter(Mandatory=$False,ValueFromPipeline=$True,Position=1,HelpMessage="Target Logfile")]
			[string]$logfile,
		[Parameter(Mandatory=$False,ValueFromPipeline=$True,Position=2,HelpMessage="Minimum Assoc Time")]
			[int]$MinAssocTime, 
			[switch]$Open=$False
 	)

 	Begin {}
 
 	Process {

		if (!$logfile) {
			# Get the current SCP Server logfile name
			$ProcessLogfile = $PlazaLogDirectory + "\PcvDcmSCPServer_" + $(Get-Process PcvDcmSCPServer).Id + ".*";
		}
		else {
			$ProcessLogfile = $logfile;
		}

		[collections.sortedlist]$AssocOpenTable = @{};
		[collections.sortedlist]$AssocCloseTable = @{};

		foreach ($line in Select-String -Pattern '(Receive Thread Started)|(Receive Thread Ended)' -Path $ProcessLogfile) {
			if($line) {
    			$OutArray = ($line.Line).Split(' ',[System.StringSplitOptions]::RemoveEmptyEntries);

    			$Date = $OutArray[7];
    			$Time = $OutArray[0];
    			$DateTime = Parse-DateTime ($Date + ' ' + $Time);

    			$ThreadId = $OutArray[12];
    			$Action = $OutArray[16];

    			$Store_AET = $OutArray[20].Replace(':','');

				$TableKey = $Store_AET + '&' + $ThreadId;
    			$PayLoad = @($DateTime, $Store_AET);

    			if ($Action -eq "Started") {
					$TableKey = $Date + '#' + $Time + '#' + $TableKey;
        			$AssocOpenTable.Add($TableKey, $PayLoad);
					Write-Verbose "Adding `$TableKey $TableKey to OpenTable with `$PayLoad value of $PayLoad"
    			}
    			else {
					if (!($AssocCloseTable.ContainsKey($TableKey))) {
            			$AssocCloseTable.Add($TableKey, $PayLoad);
						Write-Verbose "Adding `$TableKey $TableKey to CloseTable with `$PayLoad value of $PayLoad"
					}
    			}
			}
		}

		[int]$DisplayCount = 0;
        $DcmOutputArray = @();
        
		foreach ($OpenTableKey in $AssocOpenTable.Keys) {

			$CloseTableKey = $OpenTableKey.Substring($OpenTableKey.LastIndexOf('#')+1);

    		$StartArray = $AssocOpenTable.Get_Item($OpenTableKey);
    		$EndArray = $AssocCloseTable.Get_Item($CloseTableKey);
	
			$ThreadId = $OpenTableKey.Substring($OpenTableKey.IndexOf('&')+1);
	
			$Store_AET = $StartArray[1];
    		$StartDateTime = $StartArray[0];

			$DisplayLine = $True;

            $DcmOutputObj = New-Object PSObject;
	
    		if ($StartArray -and $EndArray) {
		
        		$EndDateTime = $EndArray[0];
		
				# Calculate the total time the association was open
        		[int]$AssociationTime = (New-TimeSpan -Start $StartDateTime -End $EndDateTime).TotalSeconds;
		
				# Check the filter options
				if ($AET -and ($AET -ne $Store_AET)) { $DisplayLine = $False; }
				if ($MinAssocTime -and ($AssociationTime -lt $MinAssocTime) -or $AssociationTime -lt 0) { $DisplayLine = $False; }
		
				if ($DisplayLine -eq $True) {
                    $DcmOutputObj | Add-Member -MemberType NoteProperty -Name "Thread ID" -Value $ThreadId;
                    $DcmOutputObj | Add-Member -MemberType NoteProperty -Name "AET" -Value $Store_AET;
                    $DcmOutputObj | Add-Member -MemberType NoteProperty -Name "Assoc. Open Date/Time" -Value (Format-DateTime $StartDateTime);
                    $DcmOutputObj | Add-Member -MemberType NoteProperty -Name "Assoc. Close Date/Time" -Value (Format-DateTime $EndDateTime);
                    $DcmOutputObj | Add-Member -MemberType NoteProperty -Name "Assoc. Time (sec)" -Value $AssociationTime;

                    $DcmOutputArray += $DcmOutputObj;
					$DisplayCount++;
				}
    		}
			else {
	
				# Calculate the total time the association was open
				$EndDateTime = Get-Date;
        		[int]$AssociationTime = (New-TimeSpan -Start $StartDateTime -End $EndDateTime).TotalSeconds;
		
				# Check the filter options
				if ($AET -and ($AET -ne $Store_AET)) { $DisplayLine = $False; }
		
				if ($DisplayLine -eq $True) {
                    $DcmOutputObj | Add-Member -MemberType NoteProperty -Name "Thread ID" -Value $ThreadId;
                    $DcmOutputObj | Add-Member -MemberType NoteProperty -Name "AET" -Value $Store_AET;
                    $DcmOutputObj | Add-Member -MemberType NoteProperty -Name "Assoc. Open Date/Time" -Value (Format-DateTime $StartDateTime);
                    $DcmOutputObj | Add-Member -MemberType NoteProperty -Name "Assoc. Close Date/Time" -Value (Format-DateTime $EndDateTime);
                    $DcmOutputObj | Add-Member -MemberType NoteProperty -Name "Assoc. Time (sec)" -Value $AssociationTime;

                    $DcmOutputArray += $DcmOutputObj;
					$DisplayCount++;
				}
			}
		}

		if ($DisplayCount -eq 0) {
			Write-Host "`n`t*** No Associations Found ***`n" -ForegroundColor Yellow;
		}
		else { 
			$DcmOutputArray | Format-Table -AutoSize -Wrap;
		}
	}	

	End {}
}

<#
    .SYNOPSIS
        This Cmdlet displays the ArchivedSeries logfiles, breaking it down by the hour to show the overal archiving perofrmance

    .DESCRIPTION
        This Cmdlet displays the ArchivedSeries logfiles, breaking it down by the hour to show the overal archiving perofrmance

    .EXAMPLE
        Get-ArchivePerformance -Logfile <alternate_archiving_logfile>

    .NOTES
        Displays archive performance stats
#>

function global:Get-ArchivePerformance {

    [CmdletBinding(
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]

    Param(
	    [Parameter(Mandatory=$False,ValueFromPipeline=$True,Position=0,HelpMessage="Target Logfile")]
	    [string]$logfile	
    )

    Begin {
            # Writes out the header for the Archive Performance Cmdlet
            function Write-ArchiveHeader() {
                Write-Host "";
                "{0,-14}{1,-23}{2,-18}{3,-18}" -f "Date      ","Time Range       ","Series Archived","Objects Archived";
                "{0,-14}{1,-23}{2,-18}{3,-18}" -f "==========","=================","===============","================";
            }
    }

    Process {

    if (!$logfile) {
	    # Get the current logfile directory
        $ArchivedSeriesLogDirectory = ((Get-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Siemens\PC-Viewer\PATH").HSMNASArchivedSeriesLogFolder);
    
        # Get the most recent ArchivedSeriesLogfile
        $ArchivedSeriesLogFile = ((Get-ChildItem -Path ($ArchivedSeriesLogDirectory + "\*ArchivedSeries*") | Sort-Object LastWriteTime | Select-Object -Last 1).FullName);
    }
    else {
        $ArchivedSeriesLogFile = $logfile;
    }

    [int]$LineCount = 0;
    [int]$SeriesCount = 0;
    [int]$TotalImageCount = 0;  

    if (Test-Path -Path $ArchivedSeriesLogFile) {
    
        Write-Host "";
        Write-Host "Reading Archiving statistics from $ArchivedSeriesLogFile";
    
        # Print out the header
        Write-ArchiveHeader;

        foreach ($line in Get-Content -Path $ArchivedSeriesLogFile) {
	        if($line) {
    	        $OutArray = ($line).Split(' ',[System.StringSplitOptions]::RemoveEmptyEntries);

                # Get the values from the array
    	        $Date = $OutArray[2];
    	        $Time = $OutArray[3];
                $SeriesUId = $OutArray[6];
    	        $ImgCount = $OutArray[9];

                # Parse out the date/time
    	        $DateTime = Parse-DateTime ($Date + ' ' + $Time);
        
                # Is this the first line OR is the current line date/time not within the bounds of the current hour time range? 
                if (($LineCount -eq 0) -or ($DateTime.Hour -ne $CurrentHour)) { 
               
                    # It's not the first line, so that means that the hour has changed. Print out the stats for the last hour         
                    if ($LineCount -gt 0) {
                        $TargetDateTime = if ($DateTime.DayOfYear -ne $CurrentDate) { $MinDateTime } else { $DateTime }
                        "{0,-14}{1,-23}{2,-18}{3,-18}" -f (Format-Date $TargetDateTime),(Format-TimeRange $MinDateTime $MaxDateTime),$SeriesCount,$TotalImageCount;

                	    if ($DateTime.DayOfYear -ne $CurrentDate) { Write-ArchiveHeader; }
                    }

                    # Calculate the new lower bounds for the hour
                    $MinDateTime = ([DateTime]::ParseExact($Date, "yyyy-MMM-dd-ddd", $null, [System.Globalization.DateTimeStyles]::None)); 
                    $MinDateTime = $MinDateTime.AddHours($DateTime.Hour);

                    # Calculate the new the new upper bounds for the hour
                    $MaxDateTime = $MinDateTime.AddHours(1); 

                    # Set the DayOfYear and Hour 
                    $CurrentDate = $MinDateTime.DayOfYear;
                    $CurrentHour = $MinDateTime.Hour;

                    # Reset the counters for this hour
                    $SeriesCount = 1;
                    $TotalImageCount = $ImgCount;
                }
                else {
                    # Increment the counters for this hour
                    $SeriesCount++;
                    $TotalImageCount += $ImgCount;
                }

                $LineCount++;
	        }
        }

        # Last line of the file. Print out the stats
        "{0,-14}{1,-23}{2,-18}{3,-18}" -f (Format-Date $DateTime),(Format-TimeRange $MinDateTime $MaxDateTime),$SeriesCount,$TotalImageCount+"`n";
        }
        else {
            Write-Host "`n`t*** Archived Series logfile $HSMNASArchivedSeriesLogFile was not found. ***`n" -ForegroundColor Yellow;
        }
    }

    End {}
    
}

<#
    .SYNOPSIS
        This Cmdlet displays the current archiving state, both queued and in progress jobs

    .DESCRIPTION
        This Cmdlet displays the current archiving state, both queued and in progress jobs

    .EXAMPLE
        Show-ArchivingState-LTA

    .NOTES
        Displays archive state information
#>

function global:Show-ArchivingState-LTA {

    [CmdletBinding(
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]
	
	Param()

	Begin {
			try {
				$aConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
			}
			catch {
    			Write-Error "Could not create connection to the DB server";
    			Exit;
			}
	}
	
	Process {
	
			try {
				$aConnection.Open();	
				Write-Verbose "Connection to DB instance $aSqlServer established.";
		
				$QueuedArchiveJobs = "SELECT mci.[Job UID], mci.[Copy Time], mci.[Job Start Time], ser.[Image Count]
						  			  FROM [pcv_dicom_db].[dbo].[ModifyCopyImage] mci
                                      INNER JOIN [pcv_dicom_db].[dbo].[Series] ser 
                                        ON mci.[Job UID] = ser.[Series Instance UID]
						  			  WHERE mci.[Job Status]='0'
						  			  ORDER BY mci.[Copy Time]";
					
				$RunningArchiveJobs = "SELECT mci.[Job UID], mci.[Copy Time], mci.[Job Start Time], mci.[TransactionID], head.[OrderNumber], tail.[SentImageCount], tail.[ImageCount]
						 			   FROM [pcv_dicom_db].[dbo].[ModifyCopyImage] mci 
                                       INNER JOIN [pcvnijournal].[dbo].[SendHead] head 
                                        ON mci.[Job ID] = head.[CopyJobID]
                                       INNER JOIN [pcvnijournal].[dbo].[SendTail] tail 
                                        ON head.[OrderNumber] = tail.[OrderNumber]
						  			   WHERE mci.[Job Status]='1'
						  			   ORDER BY mci.[Job Start Time]";
						  
				$aCmd = $aConnection.CreateCommand();
				$aCmd.CommandText = $QueuedArchiveJobs;
				$aReader = $aCmd.ExecuteReader();
	
				[int]$JobCount = 0;
				[int]$UnarchivedImageCount = 0;
	
				$OldestCandidate; 
				$NewestCandidate;
	
				while($aReader.Read()) {
					$JobID = $aReader.GetValue(0);
					$InsertionDateTime = Parse-DateTime $aReader.GetValue(1);
					$ExecutionDateTime = $aReader.GetValue(2);
					$ImageCount = $aReader.GetValue(3);
				
					if ($JobCount -eq 0) {
						$OldestCandidate = $InsertionDateTime;
						$NewestCandidate = $InsertionDateTime;
					}
					else {
						$OldestCandidate = if ($OldestCandidate -lt $InsertionDateTime) { $OldestCandidate } else { $InsertionDateTime }
						$NewestCandidate = if ($NewestCandidate -gt $InsertionDateTime) { $NewestCandidate } else { $InsertionDateTime }
					}
		
					$JobCount++;
					$UnarchivedImageCount += $ImageCount;
				}
				$aReader.Close();
	
				"{0,-25}" -f "`nQueued for Archiving";
				"{0,-25}" -f "====================";
				"{0,-20}{1,-20}" -f "Total Series:","$JobCount ($UnarchivedImageCount images)";

                if ($JobCount -gt 0) {
				    "{0,-20}{1,-20}" -f "Oldest in queue:", (Format-DateTime $OldestCandidate);
				    "{0,-20}{1,-20}" -f "Newest in queue:", (Format-DateTime $NewestCandidate);
                }
                else {
                     Write-Host "`n`t*** No Archiving Jobs queued ***" -ForegroundColor Yellow;    
                }
	
				"{0,-25}" -f "`n## IN PROGRESS ##`n";
	
				"{0,-70}{1,-25}{2,-25}{3,-15}{4,-8}" -f "Series UID","Placed in Queue       ","Archiving Started     ","Status","Progress";
				"{0,-70}{1,-25}{2,-25}{3,-15}{4,-8}" -f "==========","======================","======================","======","========";
	
				$aCmd = $aConnection.CreateCommand();
				$aCmd.CommandText = $RunningArchiveJobs;
				$aReader = $aCmd.ExecuteReader();
	
				$JobCount = 0;
                $StagedCount = 0;
	
				while($aReader.Read()) {
					$JobCount++;
	
					$JobID = $aReader.GetValue(0);
					$InsertionDateTime = Parse-DateTime $aReader.GetValue(1);
					$ExecutionDateTime = $aReader.GetValue(2);
					$TransactionID = $aReader.GetValue(3);
					$SentImageCount = $aReader.GetValue(5);
					$TotalImageCount = $aReader.GetValue(6);
					 
                    # Evaluate the status of the job   
                    if ($TransactionID -eq 0) {
                        if ($SentImageCount -eq 0) {
                            $JobStatus = "Staged";
                            $StagedCount++;
                        }
                        else {
                            $JobStatus = "Sending";
                        }
                    }                
                    else { 
                        if ($SentImageCount -lt $TotalImageCount) { 
                            $JobStatus = "Sending"; 
                        } 
                        else { 
                            $JobStatus = "Committing"; 
                        }
                    }
					
                    if ($JobStatus -ne "Staged") {
                        		
					    # Convert from Unix UTC, to local time
					    [datetime]$Origin = "1970-01-01 00:00:00";
					    $ExecutionDateTime = [System.TimeZone]::CurrentTimeZone.ToLocalTime($Origin.AddSeconds($ExecutionDateTime));
                        
                        # Print out the line
					    "{0,-70}{1,-25}{2,-25}{3,-15}{4,-8}" -f $JobID,(Format-DateTime $InsertionDateTime),(Format-DateTime $ExecutionDateTime),$JobStatus,"$SentImageCount/$TotalImageCount";
                    }
				}
				$aReader.Close();
                
                Write-Host "";
                if ($JobCount -lt 1) { Write-Host "`t*** No Archiving Jobs in progress ***`n" -ForegroundColor Yellow } 
                if ($StagedCount -gt 0) { 
                    "{0,-25}" -f "`n## $StagedCount series are staged to send. ##`n";
                }
			}
			catch [Exception] {
			    Write-Error "An exception occurred: $_";
			    Write-Host $StackTrace
  			}
			Finally {
				if ($aConnection.State -ne "Closed") {
			    		$aConnection.Close(); 
			            Write-Verbose "Connection to DB instance $aSqlServer closed."; 
        		}
  			}  
	}
	
	End {}
}

<#
    .SYNOPSIS
        This Cmdlet displays the current usage of the disks on the server

    .DESCRIPTION
        This Cmdlet displays the current usage of the disks on the server

    .EXAMPLE
        Show-DiskUsage

    .NOTES
        Shows disk utilization 
#>

function global:Show-DiskUsage {

    [CmdletBinding(
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]
	
	Param()

	Begin {}
	
	Process {
		$VolumeInfoArray = @();
		$VolumeInfo = (Get-WmiObject win32_volume | Where-Object {$_.FileSystem -match "NTFS" } | sort { $_.Name })

		foreach ($Volume in $VolumeInfo) {	
			$Name = $Volume.Name;
    		$Capacity = $Volume.Capacity;
    		$FreeSpace = $Volume.FreeSpace;
    		$FileSystem = $Volume.FileSystem;
    		$Label = $Volume.Label;
            $BlkSize = $Volume.BlockSize;
	
			[int]$UsedSpace = (($Capacity-$FreeSpace)/$Capacity)*100; 
	
			$VolumeInfoObj = New-Object PSObject;
			$VolumeInfoObj | Add-Member -MemberType NoteProperty -Name "Volume" -Value $Name;
			$VolumeInfoObj | Add-Member -MemberType NoteProperty -Name "FsType" -Value $FileSystem;
			$VolumeInfoObj | Add-Member -MemberType NoteProperty -Name "Size" -Value (Format-FileSize $Capacity);
			$VolumeInfoObj | Add-Member -MemberType NoteProperty -Name "Used" -Value (Format-FileSize ($Capacity-$FreeSpace));
			$VolumeInfoObj | Add-Member -MemberType NoteProperty -Name "Avail" -Value (Format-FileSize $FreeSpace);
			$VolumeInfoObj | Add-Member -MemberType NoteProperty -Name "Use%" -Value $UsedSpace;
			$VolumeInfoObj | Add-Member -MemberType NoteProperty -Name "VolumeLabel" -Value $Label;
            $VolumeInfoObj | Add-Member -MemberType NoteProperty -Name "BlockSize" -Value (Format-FileSize $BlkSize);
	
			$VolumeInfoArray += $VolumeInfoObj;
		}

		$format=@{label="Volume";Expression={$_.Volume};width=30},
				@{label="FS Type";Expression={$_.FsType};alignment="right";width=8},
				@{label="Size";Expression={$_.Size};alignment="right";width=10},
				@{label="Used";Expression={$_.Used};alignment="right";width=10},
				@{label="Avail";Expression={$_.Avail};alignment="right";width=10},
				@{label="Use%";Expression={$_."Use%"};alignment="right";width=4}, 
				@{label="Volume Label";Expression={$_.VolumeLabel};alignment="left";width=30},
                @{label="Block Size";Expression={$_.BlockSize};alignment="right";width=10}
	
		$VolumeInfoArray | Format-Table $format;
	}
	
	End {}
}
  
<#
    .SYNOPSIS
        This Cmdlet displays a count of all studies groups by their Deletion Protection flags

    .DESCRIPTION
        This Cmdlet displays a count of all studies groups by their Deletion Protection flags

    .EXAMPLE
        Show-ProtectedStudies

    .NOTES
        Displays Locked/Unlocked Studies
#>  
function global:Show-ProtectedStudies
{
    [CmdletBinding(
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]
	
    Param()
    Begin {
			try {
				$aConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
			}
			catch {
    			Write-Error "Could not create connection to the DB server";
    			Exit;
			}
	}
  
    Process
    {
        $ProtectedtStudyInfo = @();
        $ProtectedtSeriesInfo = @();
        
        try 
        {
	       $aConnection.Open();	
	       Write-Verbose "Connection to DB instance $aSqlServer established.";
		    
            $ProtectedStudyQuery = "SELECT COUNT(distinct sc.[Study Instance UID]) as 'Study Count', 
                                    CASE sc.[Delete Protect]
                                        WHEN '0' THEN 'Unlocked'
                                        WHEN '1' THEN 'Locked' 
                                        ELSE '- Null -'
                                    END,
                                    CASE sc.[AllowDeletion]
                                        WHEN '0' THEN 'Unlocked'
                                        WHEN '1' THEN 'Locked'
                                        ELSE '- Null -'                      
                                    END, 
                                    sc.[Autoload Protect]  
                                    FROM [pcv_dicom_db].[dbo].StudyComponent sc
                                    WHERE sc.[Archived] = 2
                                    GROUP BY sc.[Delete Protect], sc.[AllowDeletion], sc.[Autoload Protect]"
                            
            $ProtectedSeriesQuery ="SELECT COUNT(DISTINCT ser.[Series Instance UID]) as 'Series Count', 
                                    CASE ser.[Delete Protect]
                                        WHEN '0' THEN 'Unlocked'
                                        WHEN '1' THEN 'Locked' 
                                        ELSE '- Null -'
                                    END, 
                                    CASE ser.[AllowDeletion]
                                        WHEN '0' THEN 'Unlocked'
                                        WHEN '1' THEN 'Locked'
                                        ELSE '- Null -'
                                    END
                                    FROM [pcv_dicom_db].[dbo].Series ser
                                    WHERE ser.[Archived] = 2
                                    GROUP BY ser.[Delete Protect], ser.[AllowDeletion]"
	
	       $aCmd = $aConnection.CreateCommand();
	       $aCmd.CommandText = $ProtectedStudyQuery;
	       $aReader = $aCmd.ExecuteReader();
	
	       while($aReader.Read()) {
		      $StudyCount = $aReader.GetValue(0);
		      $DeleteProtect = $aReader.GetValue(1);
		      $AllowDeletion = $aReader.GetValue(2);
		      $AutoLoadProtect = $aReader.GetValue(3);
										
		      $ProtectedStudyInfoObj = New-Object PSObject;
		      $ProtectedStudyInfoObj | Add-Member -MemberType NoteProperty -Name "Study Count" -Value $StudyCount;
		      $ProtectedStudyInfoObj | Add-Member -MemberType NoteProperty -Name "Delete Protect" -Value $DeleteProtect;
		      $ProtectedStudyInfoObj | Add-Member -MemberType NoteProperty -Name "Allow Deletion" -Value $AllowDeletion;
		      $ProtectedStudyInfoObj | Add-Member -MemberType NoteProperty -Name "Autoload Protect" -Value $AutoLoadProtect;
			    
		      $ProtectedtStudyInfo += $ProtectedStudyInfoObj;			
	       }
	       $aReader.Close();
    
	       $aCmd = $aConnection.CreateCommand();
	       $aCmd.CommandText = $ProtectedSeriesQuery;
	       $aReader = $aCmd.ExecuteReader();  
    
	       while($aReader.Read()) {
		      $SeriesCount = $aReader.GetValue(0);
		      $DeleteProtect = $aReader.GetValue(1);
		      $AllowDeletion = $aReader.GetValue(2);
										
		      $ProtectedSeriesInfoObj = New-Object PSObject;
		      $ProtectedSeriesInfoObj | Add-Member -MemberType NoteProperty -Name "Series Count" -Value $SeriesCount;
		      $ProtectedSeriesInfoObj | Add-Member -MemberType NoteProperty -Name "Delete Protect" -Value $DeleteProtect;
		      $ProtectedSeriesInfoObj | Add-Member -MemberType NoteProperty -Name "Allow Deletion" -Value $AllowDeletion;
			    
		      $ProtectedtSeriesInfo += $ProtectedSeriesInfoObj;
            }
            $aReader.Close();			   
        }
        catch [Exception] {
	       Write-Error "An exception occurred: $_";
	       Write-Host $StackTrace
        }
        Finally {
	       if ($aConnection.State -ne "Closed") {
		      $aConnection.Close(); 
		      Write-Verbose "Connection to DB instance $aSqlServer closed."; 
            }
        }  

        Write-Host "`nProtected Studies Summary"	
        Write-Host "========================="
    		
	   $ProtectedtStudyInfo | Format-Table -AutoSize
    
       Write-Host "`nProtected Series Summary"	
       Write-Host "========================="
    		
	   $ProtectedtSeriesInfo | Format-Table -AutoSize   
  
    }
  }
  
  <#
    .SYNOPSIS
        This Cmdlet displays the status of jobs in the Send Queue 

    .DESCRIPTION
        This Cmdlet displays the status of jobs in the Send Queue

    .EXAMPLE
        Show-SendQueueStatus -DestinationAET <destination_aet> -PatientName <patient_name> -Queued -InProgress -Completed -Errored

    .NOTES
        Displays the status of jobs in the Send Queue
#>

function global:Show-SendQueueStatus {

    [CmdletBinding(
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]

    Param(
        [Parameter(Mandatory=$False,ValueFromPipeline=$True,Position=0,HelpMessage="Destination AET")]
			[string]$DestinationAET,
		[Parameter(Mandatory=$False,ValueFromPipeline=$True,Position=1,HelpMessage="Patient Name")]
			[string]$PatientName,
		[switch]$Queued=$False,
        [switch]$InProgress=$False,
        [switch]$Completed=$False,
        [switch]$Errored=$False
    )

    Begin {
		try {
			$aConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
		}
		catch {
    		Write-Error "Could not create connection to the DB server";
    		Exit;
		}
    }

    Process {
        
        # If not JobStatus filter has been specified, show everything
        if (!$Queued -and !$InProgress -and !$Completed -and !$Errored) {
            $Queued = $True;
            $InProgress = $True;
            $Completed = $True;
            $Errored = $True;
        }
        Write-Debug "Queued: $Queued`tInProgress: $InProgress`tCompleted: $Completed`tErrored: $Errored"
        
        try 
        {
	        $aConnection.Open();	
	        Write-Verbose $("Connection to DB instance $aSqlServer established.");

            if ($aConnection.State -eq "Closed") {
                Write-Error $("Connection to DB instance $aSqlServer is not open.");
  	        }
            
            $SendQueueQuery = "SELECT SUBSTRING([Description],0,CHARINDEX('=',[Description])),[SendJobIdentifier]
	                            ,CASE sh.SendLevel
                                    WHEN '0' THEN 'Series'
                                    WHEN '1' THEN 'Study'
                                    WHEN '2' THEN 'Image'
                                    WHEN '3' THEN 'Patient'
                                    ELSE 'No Status Listed'
                                END AS SendLevel
                            ,DATEADD(s,[StartTime] + datediff(s,getutcdate(),getdate()),'01/01/1970 00:00:00') AS START_TIME
                            ,DATEADD(s,[EndTime] + datediff(s,getutcdate(),getdate()),'01/01/1970 00:00:00') AS END_TIME
	                        ,st.[OwnAET],sh.[Destination],[SendCounter]
                            ,CONCAT([SentImageCount],'/',[ImageCount])
                            ,CASE st.[Status]
                                WHEN '0' THEN 'Queued'
                                WHEN '1' THEN 'In Progress'
                                WHEN '2' THEN 'Completed'
                                WHEN '3' THEN 'Errored'
                                ELSE 'No Status Listed'
                            END AS Status
                        FROM [pcvnijournal].[dbo].[SendTail] st, [pcvnijournal].[dbo].[Sendhead] sh
                        WHERE sh.OrderNumber=st.OrderNumber";
                        
                        # If the PatientName filter was specified, add it to the query 
                        if ($PatientName) {
                           $SendQueueQuery += (" AND [Description] LIKE '%" + $PatientName + "%'");  
                        }
                        
                        # If the Destination AET filter was specified, add it to the query 
                        if ($DestinationAET) {
                            $SendQueueQuery += (" AND sh.[Destination]='" + $DestinationAET + "'")
                        }
                        $SendQueueQuery += " ORDER BY [StartTime] DESC";

			
            # Look up the pertinant procedure info based on the input parameter passed.
	        $sqlCmd = New-Object System.Data.SqlClient.SqlCommand($SendQueueQuery, $aConnection);
  	        $aReader = $sqlCmd.ExecuteReader();
						
			# Define fields and objects to hold values retrieved fron the DB
            $QueueInfoArray = @();
            
            while($aReader.Read()) {

                # retrieve the DB fields
                $JobDescription = $aReader.GetValue(0);
                $JobIdentifier = $aReader.GetValue(1);
                $SendLevel = $aReader.GetValue(2);
		        $StartDateTime = $aReader.GetValue(3);
                $EndDateTime = $aReader.GetValue(4);
			    $Source = $aReader.GetValue(5);
			    $Destination = $aReader.GetValue(6);
				$SendCount = $aReader.GetValue(7);
                $SendStatus = $aReader.GetValue(8);
                $JobStatus = $aReader.GetValue(9);
				
                # Format the Date/Time fields						
				$StartdateTime = Format-DateTime $StartDateTime;     
				$EndDateTime = if ($JobStatus -eq "Queued") {"--/--/---- --:--:--"} else { Format-DateTime $EndDateTime; } 

				# Add the fields to each QueueInfoObject
                if( ($Queued -and $JobStatus -eq "Queued") -or 
                    ($InProgress -and $JobStatus -eq "In Progress") -or 
                    ($Completed -and $JobStatus -eq "Completed") -or 
                    ($Errored -and $JobStatus -eq "Errored")) {
 			
                        $QueueInfoOutputObj = New-Object PSObject;
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Job Description" -Value $JobDescription;
                        
                        # Only display the JobIdentifier if the PatientName has been specified
                        if ($PatientName) {
                            $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Job Identifier" -Value $JobIdentifier;
                        }
                        
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Send Level" -Value $SendLevel;  
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Start Date/Time" -Value $StartDateTime;
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "End Date/Time" -Value $EndDateTime;  
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Source AET" -Value $Source; 	
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Destination AET" -Value $Destination;
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Send Count" -Value $SendCount;  
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Send Status" -Value $SendStatus;
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Job Status" -Value $JobStatus;

                        # Add each QueueInfoObject to the Array
                        $QueueInfoArray += $QueueInfoOutputObj;
				        Write-Debug "`$RowCount $RowCount";
                    }
	        }

	        $aReader.Close();
						
			if ($QueueInfoArray.Length -lt 1) {
				Write-Host "`n`t*** No Send Jobs found ***`n" -ForegroundColor Yellow;
			}
            else {
                $QueueInfoArray | Format-Table -AutoSize
            }
       }
        catch [Exception] {
            Write-Error "An exception occurred: $_";
            Write-Debug $StackTrace
        }
        Finally {
  	        if ($aConnection.State -ne "Closed") {
                $aConnection.Close()  
                Write-Verbose $("Connection to DB instance $aSqlServer closed."); 
            }
        }  
    }

    End{}
}


  <#
    .SYNOPSIS
        This Cmdlet displays the status of jobs in the Retrieve Queue 

    .DESCRIPTION
        This Cmdlet displays the status of jobs in the Retrieve Queue

    .EXAMPLE
        Show-RetrieveQueueStatus -PatientName <patient_name> -Queued -InProgress -Completed -Errored

    .NOTES
        Displays the status of jobs in the Retrieve Queue
#>

function global:Show-RetrieveQueueStatus {

    [CmdletBinding(
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]

    Param(
		[Parameter(Mandatory=$False,ValueFromPipeline=$True,Position=1,HelpMessage="Patient Name")]
			[string]$PatientName,
		[switch]$Queued=$False,
        [switch]$InProgress=$False,
        [switch]$Completed=$False,
        [switch]$Errored=$False
    )

    Begin {
		try {
			$aConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
		}
		catch {
    		Write-Error "Could not create connection to the DB server";
    		Exit;
		}
    }

    Process {
        
        # If not JobStatus filter has been specified, show everything
        if (!$Queued -and !$InProgress -and !$Completed -and !$Errored) {
            $Queued = $True;
            $InProgress = $True;
            $Completed = $True;
            $Errored = $True;
        }
        Write-Debug "Queued: $Queued`tInProgress: $InProgress`tCompleted: $Completed`tErrored: $Errored"
        
        try 
        {
	        $aConnection.Open();	
	        Write-Verbose $("Connection to DB instance $aSqlServer established.");

            if ($aConnection.State -eq "Closed") {
                Write-Error $("Connection to DB instance $aSqlServer is not open.");
  	        }
            
            $Date1 = (Get-Date -Date "01/01/1970");
            $Date2 = (Get-Date).AddDays($QueryDayRange);
            $QueryStartDate = (New-TimeSpan -Start $Date1 -End $Date2).TotalSeconds;
            
            $RetrieveQueueQuery = "SELECT [Description]
                                    ,DATEADD(s,[StartTime] + datediff(s,getutcdate(),getdate()),'01/01/1970 00:00:00') AS START_TIME
                                    ,DATEADD(s,[EndTime] + datediff(s,getutcdate(),getdate()),'01/01/1970 00:00:00') AS END_TIME
	                                ,[OwnAET] as 'Requesting AET',[RetrieveAETList] as 'Source AET',[ImageCount]
                                    ,CASE [Status]
			                             WHEN '0' THEN 'Queued'
                                         WHEN '1' THEN 'In Progress'
                                         WHEN '2' THEN 'Completed'
                                         WHEN '3' THEN 'Errored'
                                         ELSE 'No Status Listed'
		                            END AS Status    
	                               ,[UserName],[JobHandlingServer],[RetrieveData]
                                    FROM [pcvnijournal].[dbo].[Retrieve]
                                    WHERE [StartTime] > $QueryStartDate";
                        
                        # If the PatientName filter was specified, add it to the query 
                        if ($PatientName) {
                           $RetrieveQueueQuery += (" AND [Description] LIKE '%" + $PatientName + "%'");  
                        }
                        $RetrieveQueueQuery += (" ORDER BY [StartTime] DESC");
                        
            Write-Debug "Query to be Executed: $RetrieveQueueQuery";           
			
            # Look up the pertinant procedure info based on the input parameter passed.
	        $sqlCmd = New-Object System.Data.SqlClient.SqlCommand($RetrieveQueueQuery, $aConnection);
  	        $aReader = $sqlCmd.ExecuteReader();
						
			# Define fields and objects to hold values retrieved fron the DB
            $QueueInfoArray = @();
            
            while($aReader.Read()) {

                # retrieve the DB fields
                $Description = $aReader.GetValue(0);
		        $StartDateTime = $aReader.GetValue(1);
                $EndDateTime = $aReader.GetValue(2);
			    $RequestingAET = $aReader.GetValue(3);
                $SourceAET = $aReader.GetValue(4);
                $ImageCount = $aReader.GetValue(5);
                $JobStatus = $aReader.GetValue(6);
			    $UserName = $aReader.GetValue(7);
				$JobHandlingServer = $aReader.GetValue(8);
                $RetrieveData = $aReader.GetValue(9);
				
                # Format the Date/Time fields						
				$StartdateTime = Format-DateTime $StartDateTime;     
				$EndDateTime = if ($JobStatus -eq "Queued") {"--/--/---- --:--:--"} else { Format-DateTime $EndDateTime; } 
                
                # Determine how the retrieve was initiated
                if ($Description.Contains("PatientJacket")) {
                    $RetrieveMode = "PatientJacket";
                    $Description = $Description.TrimStart("PatientJacket->");
                    $Description = $Description.Substring(0,$Description.IndexOf('='));
                }
                elseIf ($UserName.Contains("System")) {
                    $RetrieveMode = "Prefetch";
                    $Description = $Description.TrimStart("DICOM LTA=>");                
                }
                else {
                    $RetrieveMode = "Q/R Dialog";   
                    if ($Description.Contains("=")) {
                        $Description = $Description.Substring(0,$Description.IndexOf('='));
                    }
                }
                
                

				# Add the fields to each QueueInfoObject
                if( ($Queued -and $JobStatus -eq "Queued") -or 
                    ($InProgress -and $JobStatus -eq "In Progress") -or 
                    ($Completed -and $JobStatus -eq "Completed") -or 
                    ($Errored -and $JobStatus -eq "Errored")) {
 			
                        $QueueInfoOutputObj = New-Object PSObject;
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Job Description" -Value $Description;
                        
                        # Only display the JobIdentifier if the PatientName has been specified
                        if ($PatientName) {
                            #$QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Job Identifier" -Value $JobIdentifier;
                        }
                        
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Retrieve Mode" -Value $RetrieveMode;  
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Start Date/Time" -Value $StartDateTime;
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "End Date/Time" -Value $EndDateTime;  
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Requesting AET" -Value $RequestingAET; 	
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Source AET" -Value $SourceAET;
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Image Count" -Value $ImageCount;
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Retrieve Status" -Value $JobStatus;
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Requesting User Name" -Value $UserName;  
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Job Handling Server" -Value $JobHandlingServer;

                        # Add each QueueInfoObject to the Array
                        $QueueInfoArray += $QueueInfoOutputObj;
				        Write-Debug "`$RowCount $RowCount";
                    }
	        }

	        $aReader.Close();
						
			if ($QueueInfoArray.Length -lt 1) {
				Write-Host "`n`t*** No Retrieve Jobs found ***`n" -ForegroundColor Yellow;
			}
            else {
                $QueueInfoArray | Format-Table -AutoSize
            }
       }
        catch [Exception] {
            Write-Error "An exception occurred: $_";
            Write-Debug $StackTrace
        }
        Finally {
  	        if ($aConnection.State -ne "Closed") {
                $aConnection.Close()  
                Write-Verbose $("Connection to DB instance $aSqlServer closed."); 
            }
        }  
    }

    End{}
}


  <#
    .SYNOPSIS
        This Cmdlet displays the status of jobs in the Remote C-MOVE Request Queue 

    .DESCRIPTION
        This Cmdlet displays the status of jobs in the Remote C-MOVE Request Queue

    .EXAMPLE
        Show-RemoteCMoveRequestStatus [-RequestingAET <requesting_aet> || -PatientName <patient_name>] -Queued -InProgress -Completed -Errored

    .NOTES
        Displays the status of jobs in the Remote Retrieve Queue
#>

function global:Show-RemoteCMoveRequestStatus {

    [CmdletBinding(
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]

    Param(
        [Parameter(Mandatory=$False,ValueFromPipeline=$True,Position=0,HelpMessage="Requesting AET")]
			[string]$RequestingAET,
		[Parameter(Mandatory=$False,ValueFromPipeline=$True,Position=1,HelpMessage="Patient Name")]
			[string]$PatientName,
		[switch]$Queued=$False,
        [switch]$InProgress=$False,
        [switch]$Completed=$False,
        [switch]$Errored=$False
    )

    Begin {
		try {
			$aConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
		}
		catch {
    		Write-Error "Could not create connection to the DB server";
    		Exit;
		}
    }

    Process {
        
        # If not JobStatus filter has been specified, show everything
        if (!$Queued -and !$InProgress -and !$Completed -and !$Errored) {
            $Queued = $True;
            $InProgress = $True;
            $Completed = $True;
            $Errored = $True;
        }
        Write-Debug "Queued: $Queued`tInProgress: $InProgress`tCompleted: $Completed`tErrored: $Errored"
        
        try 
        {
	        $aConnection.Open();	
	        Write-Verbose $("Connection to DB instance $aSqlServer established.");

            if ($aConnection.State -eq "Closed") {
                Write-Error $("Connection to DB instance $aSqlServer is not open.");
  	        }
            
            # Set the default start date for the query. 
            $Date1 = (Get-Date -Date "01/01/1970");
            $Date2 = (Get-Date).AddDays($QueryDayRange);
            $QueryStartDate = (New-TimeSpan -Start $Date1 -End $Date2).TotalSeconds;
            
            $RemoteRetrieveQueueQuery = "SELECT [OrderNumber],[Description],[RetrieveLevel],[Source] as 'Requesting AET'
                                ,DATEADD(s,[StartTime] + datediff(s,getutcdate(),getdate()),'01/01/1970 00:00:00') AS START_TIME
                                ,DATEADD(s,[EndTime] + datediff(s,getutcdate(),getdate()),'01/01/1970 00:00:00') AS END_TIME
                                ,CASE [Status]
                                    WHEN '0' THEN 'Queued'
                                    WHEN '1' THEN 'In Progress'
                                    WHEN '2' THEN 'Completed'
                                    WHEN '3' THEN 'Errored'
                                    ELSE 'No Status Listed'
                                END AS Status      
                                ,[JobHandlingServer]
                                FROM [pcvnijournal].[dbo].[ImgServer]
                                WHERE [StartTime] > $QueryStartDate";
                        
                        # If the PatientName filter was specified, add it to the query 
                        if ($PatientName) {
                           $RemoteRetrieveQueueQuery += (" AND [Description] LIKE '%" + $PatientName + "%'");  
                        }
                        
                        # If the Requesting AET filter was specified, add it to the query 
                        if ($RequestingAET) {
                            $RemoteRetrieveQueueQuery += (" AND [Source]='" + $RequestingAET + "'")
                        }
                        $RemoteRetrieveQueueQuery += " order by [StartTime] desc";
                        
            Write-Debug "Query to be Executed: $RemoteRetrieveQueueQuery";
			
            # Look up the pertinant procedure info based on the input parameter passed.
	        $sqlCmd = New-Object System.Data.SqlClient.SqlCommand($RemoteRetrieveQueueQuery, $aConnection);
  	        $aReader = $sqlCmd.ExecuteReader();
						
			# Define fields and objects to hold values retrieved fron the DB
            $QueueInfoArray = @();
            
            $RowCount = 0; 
            
            while($aReader.Read()) {


                # retrieve the DB fields
                $JobIdentifier = $aReader.GetValue(0);
                $JobDescription = $aReader.GetValue(1);
                $RetrieveLevel = $aReader.GetValue(2);
			    $Requestor = $aReader.GetValue(3);
                $StartDateTime = $aReader.GetValue(4);
                $EndDateTime = $aReader.GetValue(5);
                $JobStatus = $aReader.GetValue(6);
                $JobServer = $aReader.GetValue(7);
                
                # Clean up the description field
                $JobDescription = if ($JobDescription.Contains("=")) { $JobDescription.Substring(0,$JobDescription.IndexOf('=')) }
				
                # Format the Date/Time fields						
				$StartDateTime = Format-DateTime (Parse-DateTime $StartDateTime);     
				$EndDateTime = if ($JobStatus -eq "Queued" -or $JobStatus -eq "In Progress") {"--/--/---- --:--:--"} else { Format-DateTime (Parse-DateTime $EndDateTime); } 

				# Add the fields to each QueueInfoObject
                if( ($Queued -and $JobStatus -eq "Queued") -or 
                    ($InProgress -and $JobStatus -eq "In Progress") -or 
                    ($Completed -and $JobStatus -eq "Completed") -or 
                    ($Errored -and $JobStatus -eq "Errored")) {
 			
                        $QueueInfoOutputObj = New-Object PSObject;
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Job Description" -Value $JobDescription;
                        
                        # Only display the JobIdentifier if the PatientName has been specified
                        if ($PatientName) {
                            $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Order Number" -Value $JobIdentifier;
                        }
                        
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Requesting AET" -Value $Requestor;
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Retrieve Level" -Value $RetrieveLevel;  
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Start Date/Time" -Value $StartDateTime;
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "End Date/Time" -Value $EndDateTime;  	
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Status" -Value $JobStatus;
                        $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Job Handling Server" -Value $JobServer;

                        # Add each QueueInfoObject to the Array
                        $QueueInfoArray += $QueueInfoOutputObj;
                        $RowCount++;
				        Write-Debug "`$RowCount $RowCount";
                    }
	        }

	        $aReader.Close();
						
			if ($QueueInfoArray.Length -lt 1) {
				Write-Host "`n`t*** No C-Move Jobs found ***`n" -ForegroundColor Yellow;
			}
            else {
                $QueueInfoArray | Format-Table -AutoSize
            }
       }
        catch [Exception] {
            Write-Error "An exception occurred: $_";
            Write-Debug $StackTrace
        }
        Finally {
  	        if ($aConnection.State -ne "Closed") {
                $aConnection.Close()  
                Write-Verbose $("Connection to DB instance $aSqlServer closed."); 
            }
        }  
    }

    End{}
}


  <#
    .SYNOPSIS
        This Cmdlet displays the status of jobs in the Loacal Retrieve Queue 

    .DESCRIPTION
        This Cmdlet displays the status of jobs in the Loacal Retrieve Queue 

    .EXAMPLE
        Show-LocalRetrieveQueueStatus

    .NOTES
        Displays the status of jobs in the Local Retrieve Queue
#>

function global:Show-LocalRetrieveQueueStatus {

    [CmdletBinding(
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]

    Param([Parameter(Mandatory=$False,ValueFromPipeline=$True,Position=1,HelpMessage="Patient Name")]
			[string]$PatientName)

    Begin {
		try {
			$aConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
		}
		catch {
    		Write-Error "Could not create connection to the DB server";
    		Exit;
		}
    }

    Process {
                
        try 
        {
	        $aConnection.Open();	
	        Write-Verbose $("Connection to DB instance $aSqlServer established.");

            if ($aConnection.State -eq "Closed") {
                Write-Error $("Connection to DB instance $aSqlServer is not open.");
  	        }
            
            # Only query for retrieve requests from the last 7 days
            $QueryStartDate = (Get-Date).AddDays($QueryDayRange).ToString("MM.dd.yyyy/HH:mm:ss")
            
            $LocalRetrieveQueueQuery = "select	pat.[Patient Name], 
		                                stu.[RIS Case ID], 
		                                stu.[Study Date], 
		                                det.[Series Instance UID], 
		                                '\'+SUBSTRING( arc.[ArchiveFileName],2,3)+'\'+SUBSTRING( arc.[ArchiveFileName],5,3)+'\'+SUBSTRING(arc.[ArchiveFileName],8,3), 
		                                cdq.[Requested Time], 
		                                cdq.[End Time], 
		                                CASE cdq.Status
			                                 WHEN '0' THEN 'To Be Done'
			                                 WHEN '1' THEN 'Ready'
			                                 WHEN '2' THEN 'In Progress'
			                                 WHEN '3' THEN 'Retrieve In Progress'
			                                 WHEN '4' THEN 'Completed'
			                                 WHEN '5' THEN 'Errored'
			                                 WHEN '6' THEN 'OffLine'
			                                 WHEN '7' THEN 'DICOM Error'
			                                 WHEN '8' THEN 'In Use'
			                                 WHEN '9' THEN 'Fetch in Progress'
			                                 WHEN '10' THEN 'None'
			                                     WHEN '11' THEN 'Data No Found' 
		                                END,
		                              cdq.JobHandlingServer
                                      from  pcv_dicom_db..Study stu
                                      inner join pcv_dicom_db..Patient pat
	                                       on pat.[Patient UID]=stu.[Patient UID]
                                      inner join pcvjbdb..CDQRetrieveDetails det
	                                       on det.[Study Instance UID]=stu.[Study Instance UID]
                                      inner join pcvjbdb..CDQueueJournal cdq
	                                       on cdq.[Job UID]=det.[Job UID]
                                      inner join pcv_dicom_db..Series ser
	                                       on det.[Series Instance UID]=ser.[Series Instance UID]
                                      inner join pcv_dicom_db..ArchiveFile arc
	                                       on ser.UniqueSeriesID=arc.UniqueSeriesID
                                      where cdq.[Requested Time] > '$QueryStartDate'";
                                           
                        # If the PatientName filter was specified, add it to the query 
                        if ($PatientName) {
                           $LocalRetrieveQueueQuery += (" AND pat.[Patient Name] LIKE '%" + $PatientName + "%'");  
                        }                                           
                        $LocalRetrieveQueueQuery += " order by cdq.[Requested Time] desc, pat.[Patient Name]";
			
            # Look up the pertinant procedure info based on the input parameter passed.
	        $sqlCmd = New-Object System.Data.SqlClient.SqlCommand($LocalRetrieveQueueQuery, $aConnection);
  	        $aReader = $sqlCmd.ExecuteReader();
						
			# Define fields and objects to hold values retrieved fron the DB
            $QueueInfoArray = @();
            
            while($aReader.Read()) {

                # retrieve the DB fields
                $PatientName = $aReader.GetValue(0);
                $AccessionNumber = $aReader.GetValue(1);
                $StudyDate = $aReader.GetValue(2);
		        $SeriesUid = $aReader.GetValue(3);
                $MtsPath = $aReader.GetValue(4);
			    $RqstTime = $aReader.GetValue(5);
			    $EndTime = $aReader.GetValue(6);
				$Status = $aReader.GetValue(7);
                $Server = $aReader.GetValue(8);
               
                # Format the Date/Time fields	
                $StudyDate = Format-Date (Parse-DateTime $StudyDate);					
				$RequestDateTime = Format-DateTime (Parse-DateTime $RqstTime);     
				$EndDateTime = if ($EndTime -eq "") {"--/--/---- --:--:--"} else { Format-DateTime (Parse-DateTime $EndTime); } 

				# Add the fields to each QueueInfoObject
                $QueueInfoOutputObj = New-Object PSObject;
                $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Patient Name" -Value $PatientName;
                                                
                $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Acc#" -Value $AccessionNumber;  
                $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Study Date" -Value $StudyDate;
                $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Series UID" -Value $SeriesUid;  
                $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "MTS Path" -Value ($ArchiveTarget + $MtsPath); 	
                $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Request DateTime" -Value $RequestDateTime;
                $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "End DateTime" -Value $EndDateTime;  
                $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Status" -Value $Status;
                $QueueInfoOutputObj | Add-Member -MemberType NoteProperty -Name "Job Server" -Value $Server;

                # Add each QueueInfoObject to the Array
                $QueueInfoArray += $QueueInfoOutputObj;
				Write-Debug "`$RowCount $RowCount";
	        }

	        $aReader.Close();
						
			if ($QueueInfoArray.Length -lt 1) {
				Write-Host "`n`t*** No Local Retrieve Jobs found ***`n" -ForegroundColor Yellow;
			}
            else {
                $QueueInfoArray | Format-Table -AutoSize
            }
       }
        catch [Exception] {
            Write-Error "An exception occurred: $_";
            Write-Debug $StackTrace
        }
        Finally {
  	        if ($aConnection.State -ne "Closed") {
                $aConnection.Close()  
                Write-Verbose $("Connection to DB instance $aSqlServer closed."); 
            }
        }  
    }

    End{}
}

  <#
    .SYNOPSIS
        This Cmdlet displays the number of HL7 transactions processed for a given hour on a given day 

    .DESCRIPTION
        This Cmdlet displays the number of HL7 transactions processed for a given hour on a given day 

    .EXAMPLE
        Show-HL7Processing -TargetDate <YYYY-MM-DD> -TransactionFilter <transaction_type>
    .NOTES
        Displays the number of HL7 transactions processed for a given hour on a given day
#>

function global:Show-HL7Processing {

    [CmdletBinding(
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]

    Param(
        [Parameter(Mandatory=$False,ValueFromPipeline=$True,Position=0,HelpMessage="Target Date")]
			[string]$TargetDate,
        [Parameter(Mandatory=$False,ValueFromPipeline=$True,Position=0,HelpMessage="Transaction Type")]
			[string]$TransactionFilter,
		[switch]$Details=$False
    )

    Begin {
		try {
			$aConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
		}
		catch {
    		Write-Error "Could not create connection to the DB server";
    		Exit;
		}
    }

    Process {
        
        $TargetDate = if (!($TargetDate)) { (Get-Date).ToString("yyyy-MM-dd") } else { $TargetDate }
        
        try 
        {
	        $aConnection.Open();	
	        Write-Verbose $("Connection to DB instance $aSqlServer established.");

            if ($aConnection.State -eq "Closed") {
                Write-Error $("Connection to DB instance $aSqlServer is not open.");
  	        }
            
            if (!$TransactionFilter) { 
                $TransactionQuery = "SELECT substring(CONVERT(VARCHAR,[MsgProcessingTime],120),0,14), typ.MessageTypeString, count([RowID])
                                    FROM [pcvhl7monitordb].[dbo].[HL7Monitoring] mon
                                    INNER JOIN  pcvhl7monitordb..HL7MessageTypes typ
	                                   ON mon.MessageType=typ.MessageType
                                    WHERE SUBSTRING(CONVERT(VARCHAR,[MsgProcessingTime],120),0,12) = @TargetDate
                                    GROUP BY SUBSTRING(CONVERT(VARCHAR,[MsgProcessingTime],120),0,14), typ.MessageTypeString
                                    ORDER BY SUBSTRING(CONVERT(VARCHAR,[MsgProcessingTime],120),0,14) asc";
             }
             else {             
                $TransactionQuery = "SELECT substring(CONVERT(VARCHAR,[MsgProcessingTime],120),0,14), typ.MessageTypeString, count([RowID])
                                    FROM [pcvhl7monitordb].[dbo].[HL7Monitoring] mon
                                    INNER JOIN  pcvhl7monitordb..HL7MessageTypes typ
	                                   ON mon.MessageType=typ.MessageType
                                    WHERE SUBSTRING(CONVERT(VARCHAR,[MsgProcessingTime],120),0,12) = @TargetDate
                                    AND typ.MessageTypeString LIKE @TransactionFilter
                                    GROUP BY SUBSTRING(CONVERT(VARCHAR,[MsgProcessingTime],120),0,14), typ.MessageTypeString
                                    ORDER BY SUBSTRING(CONVERT(VARCHAR,[MsgProcessingTime],120),0,14) asc";
            }
                        			
            # Look up the pertinant procedure info based on the input parameter passed.
	        $sqlCmd = New-Object System.Data.SqlClient.SqlCommand($TransactionQuery, $aConnection);
            $sqlCmd.Parameters.AddWithValue("@TargetDate", $TargetDate) | Out-Null;
            if ($TransactionFilter) { $sqlCmd.Parameters.AddWithValue("@TransactionFilter", $TransactionFilter + "%") | Out-Null; }
            
  	        $aReader = $sqlCmd.ExecuteReader();
						
			# Define fields and objects to hold values retrieved fron the DB
            $InfoArray = @();
            
            while($aReader.Read()) {

                # retrieve the DB fields
                $DateTime = $aReader.GetValue(0);
                $TransactionType = $aReader.GetValue(1);
                $Count = $aReader.GetValue(2);
                                
                [DateTime]$BeginDateTime = (Parse-DateTime ($DateTime + ":00:00")); 
                $EndDateTime = $BeginDateTime.AddHours(1);
				
				# Add the fields to each InfoObject
                $InfoOutputObj = New-Object PSObject;
                $InfoOutputObj | Add-Member -MemberType NoteProperty -Name "Date/Time Range" -Value (Format-TimeRange $BeginDateTime $EndDateTime);                        
                $InfoOutputObj | Add-Member -MemberType NoteProperty -Name "Transaction Type" -Value $TransactionType;  
                $InfoOutputObj | Add-Member -MemberType NoteProperty -Name "Count" -Value $Count;
                
                # Add each QueueInfoObject to the Array
                $InfoArray += $InfoOutputObj;
				Write-Debug "`$RowCount $RowCount";
	        }

	        $aReader.Close();
						
			if ($InfoArray.Length -lt 1) {
				Write-Host "`n`t*** No transactions found for $TargetDate ***`n" -ForegroundColor Yellow;
			}
            else {
                $InfoArray | Format-Table -AutoSize
            }
       }
        catch [Exception] {
            Write-Error "An exception occurred: $_";
            Write-Debug $StackTrace
        }
        Finally {
  	        if ($aConnection.State -ne "Closed") {
                $aConnection.Close()  
                Write-Verbose $("Connection to DB instance $aSqlServer closed."); 
            }
        }  
    }

    End{}
}



function global:Show-LastReboot {

    [CmdletBinding(
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]
    
        Param()

    Begin {}

    Process {  
        Write-Host "`nLast reboot occured on" (Format-DateTime (Get-WmiObject win32_operatingsystem | % { $_.ConverttoDateTime($_.lastbootuptime) })) "`n";
    }

    End{}
}


function global:Show-ServiceUptime {

    [CmdletBinding(
        SupportsShouldProcess=$True,
        ConfirmImpact="High"
    )]
    
    Param(  [Parameter(Mandatory=$False,ValueFromPipeline=$True,Position=0,HelpMessage="Service Name")]
			     [string]$ServiceName)

    Begin {}

    Process { 
    
        $ServiceName = if(!$ServiceName) {  "sP"; } else { $ServiceName; } 
      
        $InfoArray = @();
    
        foreach ($Event in (Get-EventLog -LogName "System" -Source "Service Control Manager" -EntryType "Information" -Message ("The " + $ServiceName + "*running*") -After (Get-Date).AddDays($QueryDayRange))) {
            $ServiceName  = ([string]$Event.Message).split(' ')[1]; 
            $StartTime = $Event.TimeGenerated; 
            
            # Add the fields to each InfoObject
            $InfoOutputObj = New-Object PSObject;           
            $InfoOutputObj | Add-Member -MemberType NoteProperty -Name "ServiceName" -Value $ServiceName;  
            $InfoOutputObj | Add-Member -MemberType NoteProperty -Name "StartDateTime" -Value (Format-DateTime $StartTime);
                
            # Add each QueueInfoObject to the Array
            $InfoArray += $InfoOutputObj;
        }
        $InfoArray | Format-Table -AutoSize;
        
    }

    End{}
}
  
  
  
  # Make public only the Cmdlet's
  Export-ModuleMember -Cmdlet Get-ProcedureInfo;
  Export-ModuleMember -Cmdlet Get-StudyInfo;
  Export-ModuleMember -Cmdlet Get-SeriesInfo;
  Export-ModuleMember -Cmdlet Get-ObjectInfo;
  Export-ModuleMember -Cmdlet Get-ArchivePerformance;
  Export-ModuleMember -Cmdlet Get-DcmReceiveInfo;
  Export-ModuleMember -Cmdlet Show-ArchivingState-LTA;
  Export-ModuleMember -Cmdlet Show-ProtectedStudies;
  Export-ModuleMember -Cmdlet Show-SendQueueStatus; 
  Export-ModuleMember -Cmdlet Show-LocalRetrieveQueueStatus;
  Export-ModuleMember -Cmdlet Show-HL7Processing;
  Export-ModuleMember -Cmdlet Show-LastReboot;
  Export-ModuleMember -Cmdlet Show-ServiceUptime;