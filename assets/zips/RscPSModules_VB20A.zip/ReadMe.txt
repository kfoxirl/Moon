Get-PatientInfo
+++++++++++++++
    DESCRIPTION 
      This Cmdlet lists Procedure level information based on the Patient ID passed. 

    EXAMPLE   
      Get-PatientInfo -PatientID <patient_id>



Get-ProcedureInfo
+++++++++++++++++
    DESCRIPTION
      This Cmdlet lists Study and Series level information based on the Accession Number passed. 

    EXAMPLE
      Get-ProcedureInfo -AccNum <accession_number>



Get-StudyInfo
+++++++++++++
    DESCRIPTION
      This Cmdlet lists Study and Series level information based on the Study Instance UID passed. 

    EXAMPLE
      Get-StudyInfo -StudyUid <study_instance_uid>



Get-SeriesInfo
++++++++++++++
    DESCRIPTION
      This Cmdlet lists Series, and Image level information based on the Series Instance UID passed. 

    EXAMPLE
      Get-SeriesInfo -SeriesUid <series_instance_uid>



Get-ObjectInfo
++++++++++++++
    DESCRIPTION
        This Cmdlet lists Image level information based on the SOP Instance UID passed. 

    EXAMPLE
        Get-ObjectInfo -SopInstanceUid <sop_instance_uid>
        


Get-DcmAssocationInfo
+++++++++++++++++++++
    DESCRIPTION
        This Cmdlet lists DICOM association information related to the DICOM SCP Server. 

    EXAMPLE
        Get-DcmAssociationInfo -AET <Application_Entity_Title> | 
							   -Logfile <alternate_logfile_path> | 
							   -MinAssocTime <associations_open_longer_than_n_seconds>
							   -Open <True|False> 
							   

							   
Get-ArchivePerformance
++++++++++++++++++++++
    DESCRIPTION
        This Cmdlet displays the ArchivedSeries logfiles, breaking it down by the hour to show the overal archiving perofrmance

    EXAMPLE
        Get-ArchivePerformance -Logfile <alternate_archiving_logfile>
        
        

Show-DiskUsage
++++++++++++++
    DESCRIPTION
        This Cmdlet displays the current usage of the disks on the server (equivalnet to Linux df -h)

    EXAMPLE
        Show-DiskUsage
        
 
        
Show-ProtectedStudies
+++++++++++++++++++++
    DESCRIPTION
        This Cmdlet displays a count of all studies groups by their Deletion Protection flags

    EXAMPLE
        Show-ProtectedStudies



Show-SendQueueStatus
++++++++++++++++++++
    DESCRIPTION
        This Cmdlet displays the status of jobs in the Send Queue

    EXAMPLE
        Show-SendQueueStatus -DestinationAET <destination_aet> -PatientName <patient_name> -Queued -InProgress -Completed -Errored
        
        
        
Show-RetrieveQueueStatus
++++++++++++++++++++++++
    DESCRIPTION
        This Cmdlet displays the status of jobs in the Retrieve Queue

    EXAMPLE
        Show-RetrieveQueueStatus -PatientName <patient_name> -Queued -InProgress -Completed -Errored
        
        
        
Show-RemoteCMoveRequestStatus
+++++++++++++++++++++++++++++
    DESCRIPTION
        This Cmdlet displays the status of jobs in the Remote C-MOVE Request Queue

    EXAMPLE
        Show-RemoteCMoveRequestStatus [-RequestingAET <requesting_aet> || -PatientName <patient_name>] -Queued -InProgress -Completed -Errored
        
        
        
Show-LocalRetrieveQueueStatus
+++++++++++++++++++++++++++++
    DESCRIPTION
        This Cmdlet displays the status of jobs in the Local Retrieve Queue 

    EXAMPLE
        Show-LocalRetrieveQueueStatus
        
        
        
Show-HL7Processing
++++++++++++++++++
    DESCRIPTION
        This Cmdlet displays the number of HL7 transactions processed for a given hour on a given day 

    EXAMPLE
        Show-HL7Processing -TargetDate <YYYY-MM-DD> -TransactionFilter <transaction_type>     
        
        
        
Show-LastReboot
+++++++++++++++
    DESCRIPTION
        This Cmdlet displays the Date/Time of the last server reboot

    EXAMPLE
        Show-LastReboot
        
        
        
Show-ServiceUptime
++++++++++++++++++
    DESCRIPTION
        This Cmdlet displays the Date/Time of each START of the named service

    EXAMPLE
        Show-ServiceUptime -ServiceName <Service Name>     