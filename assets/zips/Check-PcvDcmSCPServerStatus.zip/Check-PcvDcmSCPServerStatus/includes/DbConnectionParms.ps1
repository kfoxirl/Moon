﻿# Set DB credentials. BY default Integrated Authentication is used
$dbCred = "76492d1116743f0423413b16050a5345MgB8AEoAYQBoAEEAdABKADkAcQA5AHEANwBRADcAWQBiAE4AZgBIAGkAegBiAHcAPQA9AHwAZgAzADkANwAwAGQANwBmAGIAMwBiADUAOABlADYAOQAzADIAMQAwADYAMQA5ADQAMQA3AGUANgAyADgAOQBhADEAMQAyADUAZQAyADUAMgBlAGQAOQA2ADkAZgA2ADMAZQBlAGUANQAwAGYAZAA0ADkAZQAzADEAYwBiAGMAMQA=";
$dbUser = "dba"; 
$aDbPwd = (New-Object System.Management.Automation.PSCredential (“NONE”, ($dbCred | convertto-securestring -key (1..16)))).GetNetworkCredential().password;

$RegPath = "HKLM:\SOFTWARE\Wow6432Node\Siemens\PC-Viewer\Install_Tool";
if (Test-Path -Path $RegPath) {
    $aSqlServer = $(Get-ItemProperty -Path $RegPath).DBINSTANCE;
    $aPort = $(Get-ItemProperty -Path $RegPath).DBPORT;
}
else {
    Write-Error "Could not get DB server and/or port from registry.";
    Exit;
}

$aDbInstance = "tcp:$aSqlServer,$aPort";
$aDbName = "pcv_dicom_db";

#prepare for the sql connection

#$aConnOptions = ("Data Source=$aDbInstance; Initial Catalog=pcvusraccess;" + "UID=$dbUser;" + "PWD=$aDbPwd");
$aConnOptions = ("Server = $aDbInstance; Database = $aDbName; Integrated Security = True");

try {
    $aConnection = New-Object System.Data.SqlClient.SqlConnection($aConnOptions);
}
catch {
    Write-Error "Could not create connection to the DB server";
    Exit;
}