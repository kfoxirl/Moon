﻿# Set script to stop on errors
$ErrorActionPreference = "Stop";
        
# Set locations that script will use       
$HomeDirectory = $ScriptDirectory;
$LogsDirectory =  Join-Path $HomeDirectory "logs";
$BinDirectory =  Join-Path $HomeDirectory "bin";  
$ConfigDirectory = Join-Path $HomeDirectory "cfg";
$TempDirectory = Join-Path $HomeDirectory "tmp";
$DumpDirectory = Join-Path $HomeDirectory "dumps";
$ResourceDirectory = Join-Path $HomeDirectory "resources";

$RegKeyPath = "HKLM:\SOFTWARE\Wow6432Node\Siemens\PC-Viewer\PATH";
$RegKeyAet = "HKLM:\SOFTWARE\Wow6432Node\Siemens\PC-Viewer\PCV_BROWSER"
 
# Get the directory where the application logfiles are written       
$PlazaLogDirectory = $(Get-ItemProperty -Path $RegKeyPath).LOG; 

# Get the SCP Server Path
$PlazaBinDirectory = $(Get-ItemProperty -Path $RegKeyPath).PROGRAM;

# Get the STS base directory       
$StsPath = $(Get-ItemProperty -Path $RegKeyPath).ONLINEDIR;

# Get the local AET
$LocalAet = $(Get-ItemProperty -Path $RegKeyAet).Own_AE;

# Get the hostname
$HostName = [System.Net.Dns]::GetHostName();