
  <#
  #    Script to generate a process dump of the pcvdmapp process and collect all related logfiles. 
  #>
  
  $ScriptDirectory = Split-Path $MyInvocation.MyCommand.Path;

# Set Common parameters
. (Join-Path $ScriptDirectory .\includes\CommonParms.ps1)

# Set Common functions
. (Join-Path $ScriptDirectory .\includes\CommonFunctions.ps1)
. (Join-Path $ScriptDirectory .\includes\Out-MiniDump.ps1)

# Set DB Connection Parameters
. (Join-Path $ScriptDirectory .\includes\DbConnectionParms.ps1)

# Read in the configuration file
[xml]$CfgFile = (Get-Content -Path ($ConfigDirectory + "GetProcessDump.Config.xml"));

# Set Share Location
$RepositoryShare = $CfgFile.Settings.Repository;

# Set script location
$ScriptLogfile = $LogsDirectory + $CfgFile.Settings.LogfileName;

# Application logfile path
$AppLogfilePath = $CfgFile.Settings.AppLogfilePath;

# Set the pskill binary path
$PsKillBinary = (Join-Path $BinDirectory pskill64.exe);

# Set the procdump binary path
$ProdDumpBinary = (Join-Path $BinDirectory procdump64.exe);

$ProcessActive = Get-Process pcvdmapp -ErrorAction SilentlyContinue
if ($ProcessActive -ne $null) {

  # Get the PcvDmapp\PcvSmapp\PcvRvapp Process IDs
  $PcvDmappProcessId = (Get-Process -Name "pcvdmapp").Id
  $PcvSmappProcessId = (Get-Process -Name "pcvsmapp").Id
  

  # Dump the hung process and then copy in the logfiles for that process to the PID specific directory
  $CurrentProcessDumpDirectory = $DumpDirectory + "\PcvDmapp_" + $PcvDmappProcessId;
  if (!(Test-Path -Path $CurrentProcessDumpDirectory)) {
    New-Item $CurrentProcessDumpDirectory -Type Directory | Out-Null
  }
          
  Write-Log "I" $("Dumping the PcvDmapp process to $CurrentProcessDumpDirectory") $ScriptLogfile;
  & $ProdDumpBinary -accepteula -ma $PcvDmappProcessId $CurrentProcessDumpDirectory; 
  
  Copy-Item ($AppLogfilePath + "\pcv*app*current") -Destination $CurrentProcessDumpDirectory
  Copy-Item ($AppLogfilePath + "\*.log") -Destination $CurrentProcessDumpDirectory
  Copy-Item ($AppLogfilePath + "\*.log") -Destination $CurrentProcessDumpDirectory
  
  # Kill the hung pcvdmapp processes          
  Write-Log "I" "Killing pcvdmapp process" $ScriptLogfile;
  $CommandOutput = & $PsKillBinary $PcvDmappProcessId  

  foreach ($Line in $CommandOutput) { 
    Write-Log "D" $Line $ScriptLogfile; 
  }

  # Kill the pcvsmapp processes          
  Write-Log "I" "Killing pcvsmapp process" $ScriptLogfile;
  $CommandOutput = & $PsKillBinary $PcvSmappProcessId 

  foreach ($Line in $CommandOutput) { 
    Write-Log "D" $Line $ScriptLogfile; 
  }


  foreach ($Line in $CommandOutput) { 
    Write-Log "D" $Line $ScriptLogfile; 
  }
  #Capture Screenshots
  MakeScreenshot; 
  
  # Zip Log Files and Dmp
   [string] $destination = $CurrentProcessDumpDirectory + "_" + $env:COMPUTERNAME + "_" + [DateTime]::Now.ToString("yyyyMMdd-HHmmss") +  ".zip";
   $sourcedir = $CurrentProcessDumpDirectory + "\";

   Add-Type -Assembly System.IO.Compression.FileSystem
   [IO.Compression.ZipFile]::CreateFromDirectory($sourcedir, $destination)




  #Copy Zipped File to Share on Server
  Write-Log "I" "Copying Zip file to Server Share" $ScriptLogfile;
  
  
  Copy-Item ($destination) -Destination $RepositoryShare

  (New-Object -ComObject Wscript.Shell).Popup("Dump files captured.",0,"Done","064");
}
else {
    Write-Log "W" "PcvDmapp process was not found." $ScriptLogfile;
    (New-Object -ComObject Wscript.Shell).Popup("Plaza Viewer is Not Running, no action taken.",0,"Done","064");
}


