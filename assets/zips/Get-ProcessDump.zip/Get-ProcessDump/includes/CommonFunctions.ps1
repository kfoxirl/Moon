Function Format-FileSize() {
    Param ([int]$size)
    If     ($size -gt 1TB) {[string]::Format("{0:0.00} TB", $size / 1TB)}
    ElseIf ($size -gt 1GB) {[string]::Format("{0:0.00} GB", $size / 1GB)}
    ElseIf ($size -gt 1MB) {[string]::Format("{0:0.00} MB", $size / 1MB)}
    ElseIf ($size -gt 1KB) {[string]::Format("{0:0.00} kB", $size / 1KB)}
    ElseIf ($size -gt 0)   {[string]::Format("{0:0.00} B", $size)}
    Else                   {""}
}

Function Write-Log() {
    Param ([string]$type,
            [string]$line,
            [string]$ScriptLogfile)
  
    switch($type) { 
		'D'	{ $msgType =     " DEBUG "; }
		'W' 	{ $msgType = " WARNING "; }
		'E' 	{ $msgType = " ERROR "; }
		default { $msgType = " INFO "; } 
	}

    $ProcessId = " " + $pid;    
	
    Add-Content $ScriptLogfile $($(Get-Date).ToString("yyyy/MM/dd HH:mm:ss") + $ProcessId + $msgType + $line)
}

# Date Formats used
$DateFormats = [string[]]("yyyy.MM.dd HH:mm:ss","yyyyMMddHHmmss", "yyyyMMdd HHmmss","d/M/yyyy HH:mm:ss:fff", "yyyy-MMM-dd-ddd HH:mm:ss", "dd/MM/yyyy HH:mm:ss","MMM dd yyyy  h:mmtt");

# Function to parse various DateTime formats
function Parse-DateTime() {
	Param ([string]$InputDateTime)
	
    try {
	    [DateTime]::ParseExact($InputDateTime, $DateFormats, $null, [System.Globalization.DateTimeStyles]::None);
    }
    catch {
        return $InputDateTime;
    } 
}

# Function to insure uniform display of DateTime values
function Format-DateTime() {
	Param ([DateTime]$InputDateTime)
	
	Get-Date -Date $InputDateTime -Format "MM/dd/yyyy hh:mm:ss tt";
}

#Function to create zip files
function ZipFiles( $sourcedir, $destination )
{
   Add-Type -Assembly System.IO.Compression.FileSystem
   [IO.Compression.ZipFile]::CreateFromDirectory($sourcedir, $destination)
}

#####################################################################
# MakeScreenshot
# 
# Makes a screenshot for each attached monitor
#####################################################################
Function MakeScreenshot() {
	#load
	[void] [Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
	[void] [Reflection.Assembly]::LoadWithPartialName("System.Drawing")
	
	#Get screens 
	$aScreenArr = [System.Windows.Forms.Screen]::AllScreens
  $aCount = 0
  $x=0
	ForEach ($aScreen in $aScreenArr) 
	{
    $aScreensSize = New-Object PSObject -Property @{
			X = $x
			Y = 0
			Width = $aScreen.Bounds.Width
			Height = $aScreen.Bounds.Height
		}
  
  	#Generate screenshot
  	$Size = New-Object System.Drawing.Size $aScreensSize.Width, $aScreensSize.Height
  	$Bitmap = New-Object System.Drawing.Bitmap $aScreensSize.Width, $aScreensSize.Height
  	$Screenshot = [Drawing.Graphics]::FromImage($Bitmap)
  	$Screenshot.CopyFromScreen($aScreensSize.X, $aScreensSize.Y, 0, 0, $Size)
    $aFileName = $CurrentProcessDumpDirectory + "\ScreenShot_Screen_" + $aCount + ".jpg"
  	$Bitmap.Save($aFileName,[System.Drawing.Imaging.ImageFormat]::Jpeg)
  	$Screenshot.Dispose()
  	$Bitmap.Dispose()  
    $x += $aScreen.Bounds.Width
    $aCount ++
  }
}
