﻿# Set script to stop on errors
$ErrorActionPreference = "Stop";
        
# Set locations that script will use       
$HomeDirectory = $ScriptDirectory;
$LogsDirectory =  $HomeDirectory + "\logs\";
$BinDirectory =  $HomeDirectory + "\bin\";  
$ConfigDirectory = $HomeDirectory + "\cfg\";
$TempDirectory = $HomeDirectory + "\tmp\";
$DumpDirectory = $HomeDirectory + "\dumps";

$RegKeyPath = "HKLM:\SOFTWARE\Wow6432Node\Siemens\PC-Viewer\PATH";
$RegKeyAet = "HKLM:\SOFTWARE\Wow6432Node\Siemens\PC-Viewer\PCV_BROWSER"
 
# Get the directory where the application logfiles are written       
$PlazaLogDirectory = $(Get-ItemProperty -Path $RegKeyPath).LOG; 

# Get the SCP Server Path
$PlazaBinDirectory = $(Get-ItemProperty -Path $RegKeyPath).PROGRAM;

# Get the STS base directory       
$StsPath = $(Get-ItemProperty -Path $RegKeyPath).ONLINEDIR;

# Get the local AET
$LocalAet = $(Get-ItemProperty -Path $RegKeyAet).Own_AE;

# Get the hostname
$HostName = [System.Net.Dns]::GetHostName();