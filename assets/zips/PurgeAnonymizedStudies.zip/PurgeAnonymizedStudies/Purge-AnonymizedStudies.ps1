##################################################################
#
# Deletes anonymized research studies, both online and archived, on a daily basis 
#
# Vincent Bauer
# Siemens Medical Solutions
# 2017.07.07 - initial version
#
#
#
##################################################################

$ScriptDirectory = Split-Path $MyInvocation.MyCommand.Path;

# Set Common parameters
. (Join-Path $ScriptDirectory .\includes\CommonParms.ps1)
# Set Common functions
. (Join-Path $ScriptDirectory .\includes\CommonFunctions.ps1)
# Set DB Connection Parameters
. (Join-Path $ScriptDirectory .\includes\DbConnectionParms.ps1)

# Read in the configuration file
[xml]$CfgFile = (Get-Content -Path ($ConfigDirectory + "PurgeAnonymizedStudies.Config.xml"));

# Set script location
$ScriptLogfile = $LogsDirectory + $CfgFile.Settings.LogfileName;

Write-Log "I" "*** Daily Anonymized Study Purge Script - Start ***" $ScriptLogfile

# Define the Study UID table
[hashtable]$StudyTable = @{};

# Get the current date
$CurrentDateMask = ((Get-Date).ToString("yyyyMMdd") + "%");

# Define DB query for anonymized research exams for the current day
$AnonymizedStudyQuery = "SELECT pat.[Patient Name], stu.[RIS Case ID], stu.[Study Instance UID], stu.[Study Date], stu.[Write Date Time]
                         FROM pcv_dicom_db..Study stu 
                         INNER JOIN pcv_dicom_db..Patient pat
	                        ON pat.[Patient UID]=stu.[Patient UID]
                         WHERE pat.[Patient Name] LIKE 'BRACCO MH 151%'
                         AND stu.[Write Date Time] LIKE '$CurrentDateMask'"; 

try {
	$aConnection.Open();
    Write-Log "D" "Connection to DB open." $ScriptLogfile;
       
    # Get information for each found study
    $sqlCmd = New-Object System.Data.SqlClient.SqlCommand($AnonymizedStudyQuery, $aConnection);	
    Write-Log "I" ("Executing DB query for current day: " + (Get-Date).ToString("yyyyMMdd")) $ScriptLogfile;
	$aReader = $sqlCmd.ExecuteReader();
	
	while($aReader.Read()) {
        $PatientName = $aReader.GetValue(0);
        $AccNum = $aReader.GetValue(1);
		$StudyUID = $aReader.GetValue(2);
        $StudyDate = $aReader.GetValue(3);
        $WriteDateTime = $aReader.GetValue(4);	

        # Write details for each study to logfile
        Write-Log "I" ("PatientName: $PatientName, AccessionNumber: $AccNum, StudyUID: $StudyUID, StudyDate: $StudyDate, WriteDateTime: $WriteDateTime") $ScriptLogfile;

        # Add the Study UID to the StudyTable if it's not already there
        if (!($StudyTable.ContainsKey($StudyUID))) {
            Write-Log "I" "Adding StudyUID $StudyUID to StudyTable for deletion." $ScriptLogfile
            $StudyTable.Add($StudyUID,"");
        }
	}
	$aReader.Close();

    if ($StudyTable.Count -gt 0) {

        # Execute a study deletion for each found study 
        foreach ($StudyUid in $StudyTable.Keys) {
 
            # Delete the online study
            Write-Log "I" "Executing [pcv_dicom_db].[dbo].[DeleteStudy] for StudyUID $StudyUID" $ScriptLogfile;
            $sqlCmd = New-Object System.Data.SqlClient.SqlCommand("EXEC [pcv_dicom_db].[dbo].[DeleteStudy]  @StudyInstUID", $aConnection);	
            $sqlCmd.Parameters.AddWithValue("@StudyInstUID", $StudyUID) >> $null;
	        $sqlCmd.ExecuteNonQuery() >> $null;

            # Delete the archived study
            Write-Log "I" "Executing [pcv_dicom_db].[dbo].[delete_study_from_LTS] for StudyUID $StudyUID" $ScriptLogfile;
            $sqlCmd = New-Object System.Data.SqlClient.SqlCommand("EXEC [pcv_dicom_db].[dbo].[delete_study_from_LTS] @study_uid_in", $aConnection);	
            $sqlCmd.Parameters.AddWithValue("@study_uid_in", $StudyUID) >> $null;
	        $sqlCmd.ExecuteNonQuery() >> $null;
        }
    }
    else {
        Write-Log "I" "No qualifying studies found." $ScriptLogfile   
    }
       
}
catch [Exception] {
    Write-Log "E" "An exception occurred: $_" $ScriptLogfile;
}
Finally {
	if ($aConnection.State -ne "Closed") {
  		$aConnection.Close(); 
        Write-Log "D" "Connection to DB closed." $ScriptLogfile;
    }
}  

Write-Log "I" "*** Daily Anonymized Study Purge Script - End ***" $ScriptLogfile