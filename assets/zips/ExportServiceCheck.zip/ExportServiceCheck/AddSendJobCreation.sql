USE [pcv_dicom_db]
GO

/****** Object:  StoredProcedure [dbo].[Add_SendJob]    Script Date: 10/13/2015 5:06:37 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Add_SendJob]
	@studyuid_in varchar(64),
	@modality_in varchar(16),
	@ppsid_in varchar(64),
	@Destination_in varchar(17),
	@DestinationAlias_in varchar(20),
	@OwnAET_in varchar(17),
	@JobHandlingServer_in varchar(50),
	@CompressionMode_in int,
	@imagecount_in int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @patname1 nvarchar(70);
	declare @patname2 nvarchar(70);
	declare @patname3 nvarchar(70);
	declare @desc nvarchar(70);
	declare @v_ordernumber int;
	declare @jobIdentifier nvarchar(255);
	declare @starttime int;

	-- 1. Get the patient name for this study, and form the job identifier.
	SELECT 
		@patname1	= p.[Patient Name],
		@patname2	= p.PatientName2, 
		@patname3	= p.PatientName3 
	from pcv_dicom_db.dbo.Patient p join pcv_dicom_db.dbo.Study s 
		on (p.[Media Identifier] = s.[Media Identifier] and p.[Patient UID] = s.[Patient UID])
	where 
		s.[Media Identifier]	= N'Online' and 
		s.[Study Instance UID]	= @studyuid_in;
				
	set @jobIdentifier = @studyuid_in + '^' + @modality_in + '^' + @ppsid_in;
	set @desc = 'EXPORTTEST : ' + @patname1 + '=' + @patname2 + '=' + @patname3;
	
	-- 2. Purge the send journal if required.
	EXECUTE pcvnijournal.dbo.PurgeSendJournalEntries 50, 1;
	
	-- 3. Add SendHead Entry with [IntermediateStatus] = 0.
	INSERT INTO pcvnijournal.dbo.SendHead([Destination]
										  ,[SendLevel]
										  ,[CompressionMode]
										  ,[CompressionFactor]
										  ,[Autoroute]
										  ,[Source]
										  ,[OwnAET]
										  ,[DestinationAlias]
										  ,[JobHandlingServer]
										  ,[SourceAlias]
										  ,[FilterData]
										  ,[UserName]
										  ,[CopyJobID]
										  ,[IntermediateStatus])
									VALUES(	@Destination_in
											, 1
											, @CompressionMode_in
											, 80				-- [CompressionFactor]
											, 0 -- changed from 2 to 0 make it look like a manual send job
											, ''
											, @OwnAET_in
											, @DestinationAlias_in
											, @JobHandlingServer_in
											, ''
											, ''
											, 'System'
											, 0
											, 0);
	set @v_ordernumber = SCOPE_IDENTITY();
	
	-- 4. Add the corresponding SendTail Entry for the OrderNumber.
	set @starttime = (DATEDIFF(second,'1970-01-01 00:00:00.0000000',SYSUTCDATETIME()) - 180);
	
	INSERT INTO pcvnijournal.dbo.SendTail([OrderNumber]
										  ,[SendJobIdentifier]
										  ,[Description]
										  ,[StartTime]
										  ,[EndTime]
										  ,[SendCounter]
										  ,[SentImageCount]
										  ,[ImageCount]
										  ,[Status]
										  ,[OwnAET]
										  ,[JobHandlingServer]
										  ,[ToBeAborted]
										  ,[Number]
										  ,[Priority])
									VALUES(@v_ordernumber
											, @jobIdentifier
											, @desc
											, @starttime
											, ''
											, 5
											, 0
											, @imagecount_in
											, 0
											, @OwnAET_in
											,@JobHandlingServer_in
											, 0
											, null
											, 0);
	-- 6. Set SEND_PENDING flag for the underlying series entries.
	update pcv_dicom_db.dbo.Series
	set [Send Pending] = [Send Pending] + 1 
	where 
		[Study Instance UID]	= @studyuid_in and
		Modality				= @modality_in and 
		PPSID					= @ppsid_in;
			
	-- 5. Update SendHead Entry with [IntermediateStatus] = 1, so that it gets ready to be picked up.
	UPDATE 	pcvnijournal.dbo.SendHead 
	SET [IntermediateStatus] = 1 
	WHERE 	[OrderNumber] = @v_ordernumber;	
END

GO


